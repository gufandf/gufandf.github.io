本模型由 gufandf 制作
按照 CC-BY-SA 4.0 协议发布
使用需 署名 或 @gufandf
gufandf 的主页 https://space.bilibili.com/449104347