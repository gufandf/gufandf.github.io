import time

def fudu(datafudu):
    resultfudu = ""
    for i in datafudu:
        if i == "你":
            i = "我"
        elif i == "我":
            i = "你"
        resultfudu += i
    return(resultfudu)


print(fudu(input("你说啥?")))
time.sleep(3)
