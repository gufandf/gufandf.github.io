
execute if score #tick system.stat matches 1 run function system:tick