
execute if function map:terrain/generate/random/structure/1_0 run return fail
execute if function map:terrain/generate/random/structure/1_1 run return fail
execute if function map:terrain/generate/random/structure/1_2 run return fail
