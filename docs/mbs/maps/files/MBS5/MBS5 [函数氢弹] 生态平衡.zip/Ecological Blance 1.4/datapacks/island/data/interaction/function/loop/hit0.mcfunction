
execute if score #tick map.game matches 1 if entity @s[tag=terrain,tag=generate] run function map:terrain/interact/left_click