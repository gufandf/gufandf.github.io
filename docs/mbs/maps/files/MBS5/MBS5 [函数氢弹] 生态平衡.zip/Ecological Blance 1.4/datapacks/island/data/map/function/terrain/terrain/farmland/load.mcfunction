
scoreboard objectives add map.terrain.farmland dummy
 scoreboard players set #time map.terrain.farmland 200
 scoreboard players set #chance.wheat0 map.terrain.farmland 25
 scoreboard players set #chance.seed0 map.terrain.farmland 40