
advancement revoke @s only interaction:interact
advancement revoke @s only interaction:interact0
execute as @e[tag=interactable] run function interaction:tick1_0