
give @s carrot_on_a_stick[\
    item_model=iron_axe,\
    custom_data={\
            tag:[item,structure,remove]\
        },\
    custom_name=[{translate:island.item.remove.name}],\
    lore=[\
        [{translate:island.item.remove.lore.0}],\
        [{translate:island.item.remove.lore.1}]\
    ],\
    unbreakable={},\
    tooltip_display={hidden_components:[unbreakable]}\
]