
scoreboard objectives add map.game dummy
scoreboard objectives add map.game.ending dummy
 scoreboard players set #tick map.game 0