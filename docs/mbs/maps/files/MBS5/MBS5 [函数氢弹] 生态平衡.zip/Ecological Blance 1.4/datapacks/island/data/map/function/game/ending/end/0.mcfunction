
execute as @a run function map:game/ending/end/0_0
