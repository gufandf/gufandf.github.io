
scoreboard players set #ending map.game.ending 6
scoreboard players set #timer map.game.ending 0