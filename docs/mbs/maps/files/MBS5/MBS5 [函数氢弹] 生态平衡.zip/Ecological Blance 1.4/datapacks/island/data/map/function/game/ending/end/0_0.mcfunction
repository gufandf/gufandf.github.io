

playsound minecraft:entity.ender_dragon.death record @s ~ ~ ~ 5 0
title @s reset
title @s times 0 2000 0
title @s title [{translate:island.title.0}]
execute if score #ending0 map.game.ending matches 1 run function map:game/ending/1/tellraw
execute if score #ending0 map.game.ending matches 2 run function map:game/ending/2/tellraw
execute if score #ending0 map.game.ending matches 3 run function map:game/ending/3/tellraw
execute if score #ending0 map.game.ending matches 4 run function map:game/ending/4/tellraw
execute if score #ending0 map.game.ending matches 5 run function map:game/ending/5/tellraw
execute if score #ending0 map.game.ending matches 6 run function map:game/ending/6/tellraw
scoreboard players set #end map.game.ending 1
clear @s