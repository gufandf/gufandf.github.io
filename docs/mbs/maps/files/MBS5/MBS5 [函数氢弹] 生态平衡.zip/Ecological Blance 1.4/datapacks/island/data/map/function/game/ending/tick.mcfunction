
execute if score #ending map.game.ending matches 1 run function map:game/ending/1/tick
execute if score #ending map.game.ending matches 2 run function map:game/ending/2/tick
execute if score #ending map.game.ending matches 6 run function map:game/ending/6/tick
