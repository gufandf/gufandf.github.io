
kill @e[type=armor_stand,tag=text,tag=tutorial]
summon armor_stand 10 5 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.0_4}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.25 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.0_3}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.5 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.0_2}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.75 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.0_1}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 6 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.0}],CustomNameVisible:1b,Marker:1b,Invisible:1b}

summon armor_stand 10 5 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.1_4}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.25 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.1_3}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.5 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.1_2}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.75 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.1_1}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 6 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.1}],CustomNameVisible:1b,Marker:1b,Invisible:1b}

summon armor_stand 10 5 10 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.2_2}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.25 10 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.2_1}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 10 5.5 10 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.2}],CustomNameVisible:1b,Marker:1b,Invisible:1b}

summon armor_stand 22 5 10 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.3_3}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.25 10 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.3_2}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.5 10 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.3_1}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.75 10 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.3}],CustomNameVisible:1b,Marker:1b,Invisible:1b}

summon armor_stand 22 5 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.4_3}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.25 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.4_2}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.5 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.4_1}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.75 16 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.4}],CustomNameVisible:1b,Marker:1b,Invisible:1b}

summon armor_stand 22 5 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.5_2}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.25 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.5_1}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
summon armor_stand 22 5.5 22 {Tags:[text,tutorial],CustomName:[{translate:island.tutorial.5}],CustomNameVisible:1b,Marker:1b,Invisible:1b}
