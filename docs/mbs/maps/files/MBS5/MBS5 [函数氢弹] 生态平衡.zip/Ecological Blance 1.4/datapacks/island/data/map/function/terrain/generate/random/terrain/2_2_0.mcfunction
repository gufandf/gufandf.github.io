
scoreboard players set #test map.generate.stat 0
scoreboard players operation @s map.terrain = #terrain map.generate.stat