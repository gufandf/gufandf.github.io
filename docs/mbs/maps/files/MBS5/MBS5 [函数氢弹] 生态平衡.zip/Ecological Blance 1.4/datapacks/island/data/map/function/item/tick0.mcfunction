
execute if entity @s[gamemode=adventure] run function map:item/glow/0