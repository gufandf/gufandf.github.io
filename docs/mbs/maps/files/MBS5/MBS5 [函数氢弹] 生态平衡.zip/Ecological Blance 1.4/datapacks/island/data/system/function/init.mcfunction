
function system:reset
function system:load
weather clear
