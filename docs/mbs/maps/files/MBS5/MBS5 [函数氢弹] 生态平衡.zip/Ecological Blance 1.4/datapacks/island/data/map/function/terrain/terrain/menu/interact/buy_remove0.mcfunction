
execute if items entity @s container.* *[custom_data~{tag:[remove]}] run playsound entity.enderman.teleport ambient @s ~ ~ ~ 1 0 0
execute if items entity @s container.* *[custom_data~{tag:[remove]}] run return run tellraw @s [{translate:island.menu.tellraw.1}]
 function map:item/_get_item/remove
tag @s remove target