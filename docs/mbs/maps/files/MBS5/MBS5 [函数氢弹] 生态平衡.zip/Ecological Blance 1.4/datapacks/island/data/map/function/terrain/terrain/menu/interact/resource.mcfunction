
execute store result score #wheat map.terrain.menu run execute if items entity @s container.* *[custom_data~{tag:[wheat]}]
execute store result score #seed map.terrain.menu run execute if items entity @s container.* *[custom_data~{tag:[seed]}]
execute store result score #wood map.terrain.menu run execute if items entity @s container.* *[custom_data~{tag:[wood]}]
execute store result score #porkchop map.terrain.menu run execute if items entity @s container.* *[custom_data~{tag:[porkchop]}]

execute if score #wheat map.terrain.menu < #price.wheat map.terrain.menu run playsound entity.enderman.teleport ambient @s ~ ~ ~ 1 0 0
execute if score #wheat map.terrain.menu < #price.wheat map.terrain.menu run return run tellraw @s [{translate:island.menu.tellraw.0}]
execute if score #wood map.terrain.menu < #price.wood map.terrain.menu run playsound entity.enderman.teleport ambient @s ~ ~ ~ 1 0 0
execute if score #wood map.terrain.menu < #price.wood map.terrain.menu run return run tellraw @s [{translate:island.menu.tellraw.0}]
execute if score #seed map.terrain.menu < #price.seed map.terrain.menu run playsound entity.enderman.teleport ambient @s ~ ~ ~ 1 0 0
execute if score #seed map.terrain.menu < #price.seed map.terrain.menu run return run tellraw @s [{translate:island.menu.tellraw.0}]
execute if score #porkchop map.terrain.menu < #price.porkchop map.terrain.menu run playsound entity.enderman.teleport ambient @s ~ ~ ~ 1 0 0
execute if score #porkchop map.terrain.menu < #price.porkchop map.terrain.menu run return run tellraw @s [{translate:island.menu.tellraw.0}]
scoreboard players set #buy map.terrain.menu 1