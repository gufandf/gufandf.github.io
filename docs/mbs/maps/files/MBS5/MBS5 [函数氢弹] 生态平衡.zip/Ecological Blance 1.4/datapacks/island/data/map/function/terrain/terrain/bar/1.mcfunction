
scoreboard players operation #length0 map.terrain.bar = #length map.terrain.bar
scoreboard players operation #length0 map.terrain.bar *= #value map.generate.stat
scoreboard players operation #length0 map.terrain.bar /= #max map.generate.stat
scoreboard players operation #length1 map.terrain.bar = #length map.terrain.bar
scoreboard players operation #length1 map.terrain.bar -= #length0 map.terrain.bar

execute store result entity @s data.text.0 int 1 run scoreboard players get #length0 map.terrain.bar
execute store result entity @s data.text.1 int 1 run scoreboard players get #length1 map.terrain.bar
function map:terrain/terrain/bar/1_0 with entity @s data.text
function map:terrain/terrain/bar/1_1 with entity @s data.text
