
execute as @e[type=interaction,tag=terrain,tag=generate] run function map:terrain/ebi/calculate/1

scoreboard players remove #ebi ebi 320