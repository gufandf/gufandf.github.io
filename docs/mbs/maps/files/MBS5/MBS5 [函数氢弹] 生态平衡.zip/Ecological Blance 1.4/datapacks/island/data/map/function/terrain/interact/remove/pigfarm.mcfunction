
execute as @p[tag=chosen] run function map:terrain/interact/remove/pigfarm0
particle cloud ~ ~ ~ 0.2 0.2 0.2 0.05 5 force @a
playsound entity.pig.death record @a ~ ~ ~ 2 0.75
