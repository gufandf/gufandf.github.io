
tellraw @s [{translate:island.tellraw.ending.0}]
tellraw @s [{translate:island.tellraw.ending6.0}]
tellraw @s [{translate:island.tellraw.ending6.1}]
tellraw @s [{translate:island.tellraw.ending6.2}]
tellraw @s [{translate:island.tellraw.ending6.3}]
tellraw @s [{translate:island.tellraw.ending.0}]