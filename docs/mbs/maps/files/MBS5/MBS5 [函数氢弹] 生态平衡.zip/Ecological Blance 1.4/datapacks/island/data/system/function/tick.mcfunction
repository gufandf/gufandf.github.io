
function map:tick
execute as @a run function system:tick0
execute as @e run function system:tick1