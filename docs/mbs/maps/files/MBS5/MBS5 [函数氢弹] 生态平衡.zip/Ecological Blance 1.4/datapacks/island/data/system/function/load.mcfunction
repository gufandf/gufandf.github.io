
function map:load
function interaction:load
function inventory:load


scoreboard objectives add system.stat dummy
 scoreboard players set #tick system.stat 1
scoreboard objectives add system.quitgame minecraft.custom:minecraft.leave_game
scoreboard objectives add uuid dummy
 scoreboard players set #player_uuid uuid 0
scoreboard objectives add uuid0 dummy
scoreboard objectives add uuid1 dummy
scoreboard objectives add uuid2 dummy
scoreboard objectives add uuid3 dummy

scoreboard objectives add number dummy
function system:number

