
scoreboard players add #i0 map.generate.stat 1
summon interaction ~ ~1 ~ {Tags:[generate,terrain,interactable,chosen],height:0.0125,width:1,response:true}
scoreboard players operation @n[type=interaction,tag=chosen] map.terrain.x = #i map.generate.stat
scoreboard players operation @n[type=interaction,tag=chosen] map.terrain.y = #i0 map.generate.stat
scoreboard players set @n[type=interaction,tag=chosen] map.terrain 0
tag @n[type=interaction,tag=chosen] remove chosen
execute if score #i0 map.generate.stat < #loop map.generate.stat positioned ~ ~ ~1 run return run function map:terrain/generate/random/terrain/1_1
