
scoreboard objectives add map.terrain.menu dummy
 scoreboard players set #price.farmland.wheat map.terrain.menu 0
 scoreboard players set #price.farmland.wood map.terrain.menu 6
 scoreboard players set #price.farmland.seed map.terrain.menu 3
 scoreboard players set #price.farmland.porkchop map.terrain.menu 0
 
 scoreboard players set #price.pigfarm.wheat map.terrain.menu 5
 scoreboard players set #price.pigfarm.wood map.terrain.menu 8
 scoreboard players set #price.pigfarm.seed map.terrain.menu 0
 scoreboard players set #price.pigfarm.porkchop map.terrain.menu 0
 
 scoreboard players set #price.regrasser.wheat map.terrain.menu 6
 scoreboard players set #price.regrasser.wood map.terrain.menu 5
 scoreboard players set #price.regrasser.seed map.terrain.menu 0
 scoreboard players set #price.regrasser.porkchop map.terrain.menu 4
 
 scoreboard players set #price.bruh.wheat map.terrain.menu 40
 scoreboard players set #price.bruh.wood map.terrain.menu 10
 scoreboard players set #price.bruh.seed map.terrain.menu 40
 scoreboard players set #price.bruh.porkchop map.terrain.menu 10
 
 scoreboard players set #price.dirt.wheat map.terrain.menu 7
 scoreboard players set #price.dirt.wood map.terrain.menu 10
 scoreboard players set #price.dirt.seed map.terrain.menu 8
 scoreboard players set #price.dirt.porkchop map.terrain.menu 4
 
 scoreboard players set #price.remove.wheat map.terrain.menu 0
 scoreboard players set #price.remove.wood map.terrain.menu 0
 scoreboard players set #price.remove.seed map.terrain.menu 0
 scoreboard players set #price.remove.porkchop map.terrain.menu 0

scoreboard objectives add map.terrain.menu.uuid dummy
scoreboard objectives add map.terrain.menu.page dummy
scoreboard objectives add map.terrain.menu.item dummy