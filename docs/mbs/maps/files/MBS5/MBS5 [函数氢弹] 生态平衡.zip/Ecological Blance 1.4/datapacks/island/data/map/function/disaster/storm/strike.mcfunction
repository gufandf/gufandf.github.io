
particle wax_off ~ ~ ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.1 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.2 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.3 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.4 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.5 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.6 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.7 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.8 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~0.9 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.0 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.1 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.2 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.3 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.4 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.5 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.6 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.7 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.8 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~1.9 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.0 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.1 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.2 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.3 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.4 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.5 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.6 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.7 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.8 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~2.9 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.0 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.1 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.2 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.3 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.4 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.5 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.6 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.7 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.8 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~3.9 ~ 0 0 0 0 1 force @a
particle wax_off ~ ~4.0 ~ 0 0 0 0 1 force @a
playsound entity.lightning_bolt.impact ambient @a ~ ~ ~ 1 1 0
particle flash{color:[1,1,1,1]} ~ ~1 ~ 0 0 0 0 0 force @a
scoreboard players set @s map.storm 0

execute if score @s map.vine matches 1 run scoreboard players set @s map.vine 0
execute if score @s map.vine matches 1 run scoreboard players set @s map.terrain 1
execute if score @s map.structure matches 1.. unless score @s map.structure matches 2 unless score @s map.terrain matches 3..6 run scoreboard players set @s map.terrain 2
execute if score @s map.structure matches 1.. unless score @s map.structure matches 2 run return run scoreboard players set @s map.structure 0
execute if score @s map.structure matches 2 run return run scoreboard players set @s map.structure 0
execute if score @s map.terrain matches 0 run return run scoreboard players set @s map.terrain 1
execute if score @s map.terrain matches 2 run return run scoreboard players set @s map.terrain 1