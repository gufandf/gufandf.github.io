#4..10
function map:item/_get_item/resource/wheat
function map:item/_get_item/resource/wheat
function map:item/_get_item/resource/wheat
function map:item/_get_item/resource/wheat
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/wheat
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/wheat
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/wheat
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/wheat
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/wheat
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/wheat
#3..7
function map:item/_get_item/resource/seed
function map:item/_get_item/resource/seed
function map:item/_get_item/resource/seed
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/seed
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/seed
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/seed
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wheat0 map.terrain.farmland run function map:item/_get_item/resource/seed
