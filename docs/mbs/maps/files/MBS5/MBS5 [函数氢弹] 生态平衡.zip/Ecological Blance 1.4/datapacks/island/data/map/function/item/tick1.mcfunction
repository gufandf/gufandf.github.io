
function map:item/glow/tick1