
summon interaction ~ ~ ~ {Tags:[position_fix,ride,chosen],width:0,height:0.125}
ride @n[type=interaction,tag=chosen] mount @s
tag @e[tag=chosen] remove chosen
data modify entity @s height set value 0.0125
scoreboard players set @s map.terrain_timer 0