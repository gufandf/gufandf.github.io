
function map:terrain/generate/random/structure/0