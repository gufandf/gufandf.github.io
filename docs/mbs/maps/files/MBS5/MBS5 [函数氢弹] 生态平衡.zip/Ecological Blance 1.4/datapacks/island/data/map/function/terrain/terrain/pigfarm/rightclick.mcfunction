
execute if score @s map.terrain_timer matches 1.. run return run function map:terrain/terrain/pigfarm/harvest
execute unless score @s map.terrain_timer matches 1.. run return run function map:terrain/terrain/pigfarm/sow