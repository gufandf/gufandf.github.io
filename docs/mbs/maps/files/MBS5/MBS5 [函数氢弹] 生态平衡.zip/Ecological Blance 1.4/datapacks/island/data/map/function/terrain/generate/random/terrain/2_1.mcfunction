
tag @e[tag=chosen] remove chosen

execute if function map:terrain/generate/random/terrain/2_2 run return run execute as @e[type=interaction,scores={map.terrain=0},limit=1,sort=random] at @s run function map:terrain/generate/random/terrain/2_1_0
scoreboard players remove #amount.type map.generate.stat 1
execute unless score #amount.type map.generate.stat matches 1.. run return fail
execute as @e[type=interaction,scores={map.terrain=0..}] if score @s map.terrain = #terrain map.generate.stat run tag @s add chosen
execute at @e[type=interaction,scores={map.terrain=0..},tag=chosen,limit=1,sort=random] run function map:terrain/generate/random/terrain/2_1