
scoreboard players operation #range interaction.range = #max_range interaction.range
execute if score #tick map.game matches 1 if entity @s[tag=terrain,tag=generate] run function map:terrain/interact/right_click
tag @p[tag=chosen] remove chosen
