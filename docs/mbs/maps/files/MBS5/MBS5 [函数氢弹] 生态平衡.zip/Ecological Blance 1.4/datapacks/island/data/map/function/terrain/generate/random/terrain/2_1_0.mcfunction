
scoreboard players operation @s map.terrain = #terrain map.generate.stat
scoreboard players remove #amount.type map.generate.stat 1
execute if score #amount.type map.generate.stat matches 1.. run function map:terrain/generate/random/terrain/2_1