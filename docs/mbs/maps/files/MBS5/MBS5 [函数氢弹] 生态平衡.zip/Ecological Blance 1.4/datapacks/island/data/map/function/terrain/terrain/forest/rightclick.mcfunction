
function map:terrain/terrain/forest/harvest