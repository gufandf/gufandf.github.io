
scoreboard players operation #max map.generate.weight = #grass map.generate.weight
scoreboard players operation #max map.generate.weight += #stone map.generate.weight
scoreboard players operation #max map.generate.weight += #sand map.generate.weight 
scoreboard players operation #max map.generate.weight += #water map.generate.weight
scoreboard players operation #max map.generate.weight += #seawater map.generate.weight
scoreboard players operation #max map.generate.weight += #freshwater map.generate.weight
scoreboard players operation #max map.generate.weight += #seawater0 map.generate.weight


scoreboard players operation #amount map.generate.stat = #size map.generate.weight
scoreboard players operation #amount map.generate.stat += #size map.generate.weight
scoreboard players add #amount map.generate.stat 1
scoreboard players operation #x_max map.generate.stat = #loop map.generate.stat
scoreboard players operation #y_max map.generate.stat = #loop map.generate.stat
scoreboard players operation #amount map.generate.stat *= #amount map.generate.stat

#固定地块
scoreboard players set #specific_x map.generate.stat 1
scoreboard players set #specific_y map.generate.stat 1
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.x = #specific_x map.generate.stat run scoreboard players set @s map.terrain -1
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.y = #specific_y map.generate.stat run scoreboard players set @s map.terrain -1
scoreboard players set #specific_x map.generate.stat 2
scoreboard players set #specific_y map.generate.stat 2
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.x = #specific_x map.generate.stat run scoreboard players set @s map.terrain -1
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.y = #specific_y map.generate.stat run scoreboard players set @s map.terrain -1
scoreboard players set #specific_x map.generate.stat 3
scoreboard players set #specific_y map.generate.stat 3
#execute as @e[type=interaction,tag=terrain] if score @s map.terrain.x = #specific_x map.generate.stat run scoreboard players set @s map.terrain -1
#execute as @e[type=interaction,tag=terrain] if score @s map.terrain.y = #specific_y map.generate.stat run scoreboard players set @s map.terrain -1
scoreboard players operation #specific_x map.generate.stat = #x_max map.generate.stat
scoreboard players operation #specific_y map.generate.stat = #y_max map.generate.stat
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.x = #specific_x map.generate.stat run scoreboard players set @s map.terrain -1
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.y = #specific_y map.generate.stat run scoreboard players set @s map.terrain -1
scoreboard players remove #specific_x map.generate.stat 1
scoreboard players remove #specific_y map.generate.stat 1
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.x = #specific_x map.generate.stat run scoreboard players set @s map.terrain -1
execute as @e[type=interaction,tag=terrain] if score @s map.terrain.y = #specific_y map.generate.stat run scoreboard players set @s map.terrain -1
scoreboard players remove #specific_x map.generate.stat 1
scoreboard players remove #specific_y map.generate.stat 1
#execute as @e[type=interaction,tag=terrain] if score @s map.terrain.x = #specific_x map.generate.stat run scoreboard players set @s map.terrain -1
#execute as @e[type=interaction,tag=terrain] if score @s map.terrain.y = #specific_y map.generate.stat run scoreboard players set @s map.terrain -1
execute as @e[type=interaction,tag=terrain,scores={map.terrain=-1}] run scoreboard players remove #amount map.generate.stat 1

#随机地块
scoreboard players operation #amount.grass map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.grass map.generate.stat *= #grass map.generate.weight
scoreboard players operation #amount.grass map.generate.stat /= #max map.generate.weight

scoreboard players operation #amount.stone map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.stone map.generate.stat *= #stone map.generate.weight
scoreboard players operation #amount.stone map.generate.stat /= #max map.generate.weight

scoreboard players operation #amount.sand map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.sand map.generate.stat *= #sand map.generate.weight
scoreboard players operation #amount.sand map.generate.stat /= #max map.generate.weight

scoreboard players operation #amount.water map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.water map.generate.stat *= #water map.generate.weight
scoreboard players operation #amount.water map.generate.stat /= #max map.generate.weight

scoreboard players operation #amount.seawater map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.seawater map.generate.stat *= #seawater map.generate.weight
scoreboard players operation #amount.seawater map.generate.stat /= #max map.generate.weight

scoreboard players operation #amount.freshwater map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.freshwater map.generate.stat *= #freshwater map.generate.weight
scoreboard players operation #amount.freshwater map.generate.stat /= #max map.generate.weight

scoreboard players operation #amount.seawater0 map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.seawater0 map.generate.stat *= #seawater0 map.generate.weight
scoreboard players operation #amount.seawater0 map.generate.stat /= #max map.generate.weight

execute if score #amount.stone map.generate.stat matches 1.. as @e[type=interaction,tag=terrain,scores={map.terrain=0},sort=random,limit=1] run scoreboard players set @s map.terrain 1
execute if score #amount.sand map.generate.stat matches 1.. as @e[type=interaction,tag=terrain,scores={map.terrain=0},sort=random,limit=1] run scoreboard players set @s map.terrain 2
execute if score #amount.water map.generate.stat matches 1.. as @e[type=interaction,tag=terrain,scores={map.terrain=0},sort=random,limit=1] run scoreboard players set @s map.terrain 3
execute if score #amount.seawater map.generate.stat matches 1.. as @e[type=interaction,tag=terrain,scores={map.terrain=0},sort=random,limit=1] run scoreboard players set @s map.terrain 4
execute if score #amount.freshwater map.generate.stat matches 1.. as @e[type=interaction,tag=terrain,scores={map.terrain=0},sort=random,limit=1] run scoreboard players set @s map.terrain 5
execute if score #amount.seawater0 map.generate.stat matches 1.. as @e[type=interaction,tag=terrain,scores={map.terrain=0},sort=random,limit=1] run scoreboard players set @s map.terrain 6

execute as @e[type=interaction,tag=terrain,scores={map.terrain=1..}] at @s run function map:terrain/generate/random/terrain/2_0


scoreboard players set @e[type=interaction,tag=terrain,scores={map.terrain=-1}] map.terrain 4

function map:terrain/generate/random/terrain/2_3