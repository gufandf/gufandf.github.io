

execute if score #amount.grass map.generate.stat matches 1.. run scoreboard players set @s map.structure 1
execute if score #amount.grass map.generate.stat matches 1.. run return run scoreboard players remove #amount.grass map.generate.stat 1