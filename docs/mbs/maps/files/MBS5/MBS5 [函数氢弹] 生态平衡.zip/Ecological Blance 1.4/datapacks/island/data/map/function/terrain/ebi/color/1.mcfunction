
scoreboard players operation #color ebi = #ebi0 ebi
scoreboard players remove #color ebi 10
scoreboard players set #r ebi 255
scoreboard players set #g ebi 0
scoreboard players set #b ebi 0
scoreboard players operation #color ebi *= #255 number
scoreboard players operation #color ebi /= #40 number

scoreboard players operation #g ebi += #color ebi

scoreboard players operation #rgb.R ebi = #r ebi
scoreboard players operation #rgb.G ebi = #g ebi
scoreboard players operation #rgb.B ebi = #b ebi

function map:terrain/ebi/rgb_to_hexadecimal/0