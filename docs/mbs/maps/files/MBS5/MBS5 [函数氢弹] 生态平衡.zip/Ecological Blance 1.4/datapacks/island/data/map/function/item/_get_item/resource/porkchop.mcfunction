
give @s iron_nugget[\
    item_model=porkchop,\
    custom_data={\
            tag:[item,resource,porkchop]\
        },\
    custom_name=[{translate:island.item.resource.porkchop.name}],\
    lore=[\
        [{translate:island.item.resource.porkchop.lore.0}],\
        [{translate:island.item.resource.porkchop.lore.1}]\
    ],\
    unbreakable={},\
    tooltip_display={hidden_components:[unbreakable]}\
]