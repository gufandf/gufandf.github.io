
execute if score #ebi0 ebi matches ..50 run return run scoreboard players set #ending map.game.ending 0
execute if score #ebi0 ebi matches 100.. unless entity @e[type=interaction,tag=terrain,scores={map.vine=1}] run function map:game/ending/3/end
execute unless entity @e[type=interaction,tag=terrain,scores={map.vine=0,map.terrain=0}] run function map:game/ending/2/end
scoreboard players set #random map.game 0
execute if score #ebi ebi matches 50.. store result score #random map.game run random value 0..600
execute unless score #random map.game matches 600 run return fail
execute as @e[type=interaction,tag=terrain,scores={map.structure=2},limit=1,sort=random] run scoreboard players set @s map.vine 1