
execute if score #ebi0 ebi matches ..10 run function map:terrain/ebi/color/0
execute if score #ebi0 ebi matches 11..30 run function map:terrain/ebi/color/1
execute if score #ebi0 ebi matches 31..50 run function map:terrain/ebi/color/2
execute if score #ebi0 ebi matches 51..71 run function map:terrain/ebi/color/3
execute if score #ebi0 ebi matches 71..90 run function map:terrain/ebi/color/4
execute if score #ebi0 ebi matches 91.. run function map:terrain/ebi/color/5
function map:terrain/ebi/actionbar0 with storage map operation