
summon marker ~ ~ ~ {UUID:[I;1,1,1,1]}
tp 00000001-0000-0001-0000-000100000001 @s
execute as 00000001-0000-0001-0000-000100000001 at @s run tp @s ~ ~1.6 ~

execute at 00000001-0000-0001-0000-000100000001 as @e[distance=..10] run function map:item/glow/1

kill 00000001-0000-0001-0000-000100000001