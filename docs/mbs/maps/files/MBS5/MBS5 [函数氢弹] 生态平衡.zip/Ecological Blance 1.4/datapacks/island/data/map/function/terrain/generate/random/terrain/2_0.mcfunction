
execute if score @s map.terrain matches 0 run scoreboard players operation #amount.type map.generate.stat = #amount.grass map.generate.stat
execute if score @s map.terrain matches 1 run scoreboard players operation #amount.type map.generate.stat = #amount.stone map.generate.stat
execute if score @s map.terrain matches 2 run scoreboard players operation #amount.type map.generate.stat = #amount.sand map.generate.stat
execute if score @s map.terrain matches 3 run scoreboard players operation #amount.type map.generate.stat = #amount.water map.generate.stat
execute if score @s map.terrain matches 4 run scoreboard players operation #amount.type map.generate.stat = #amount.seawater map.generate.stat
execute if score @s map.terrain matches 5 run scoreboard players operation #amount.type map.generate.stat = #amount.freshwater map.generate.stat
execute if score @s map.terrain matches 6 run scoreboard players operation #amount.type map.generate.stat = #amount.seawater0 map.generate.stat
scoreboard players remove #amount.type map.generate.stat 1
scoreboard players operation #terrain map.generate.stat = @s map.terrain

execute if score #amount.type map.generate.stat matches 1.. run function map:terrain/generate/random/terrain/2_1