
execute as @s at @s run function map:terrain/terrain/menu/menu_item/detect

function map:terrain/terrain/menu/menu_item/target_player
clear @p[tag=target] *[custom_data~{tag:["clear","minecart"]}]
execute as @e[type=item,tag=!display,nbt={Item:{components:{"minecraft:custom_data":{tag:["clear"]}}}}] run function system:death
tag @a[tag=target] remove target
data modify entity @s Items set value []
execute if score @s map.terrain.menu.page matches 1 run function map:terrain/terrain/menu/menu_item/menu1
#execute if score @s map.terrain.menu.page matches 2 run function map:terrain/terrain/menu/menu_item/menu2
