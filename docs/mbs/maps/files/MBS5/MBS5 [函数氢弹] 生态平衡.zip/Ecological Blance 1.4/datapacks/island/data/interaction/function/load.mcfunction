
scoreboard objectives add interaction.state dummy

scoreboard objectives add interaction.range dummy
scoreboard players set #max_range interaction.range 12

scoreboard objectives add interaction.right_click dummy
scoreboard objectives add interaction.right_click0 minecraft.used:carrot_on_a_stick
scoreboard objectives add interaction.left_click dummy
advancement revoke @a only interaction:interact