
data modify entity @s Health set value 1024f
execute on attacker run scoreboard players set @s interaction.left_click 1
