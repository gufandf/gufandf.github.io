
give @s iron_nugget[\
    item_model=oak_log,\
    custom_data={\
            tag:[item,resource,wood]\
        },\
    custom_name=[{translate:island.item.resource.wood.name}],\
    lore=[\
        [{translate:island.item.resource.wood.lore.0}],\
        [{translate:island.item.resource.wood.lore.1}]\
    ],\
    unbreakable={},\
    tooltip_display={hidden_components:[unbreakable]}\
]