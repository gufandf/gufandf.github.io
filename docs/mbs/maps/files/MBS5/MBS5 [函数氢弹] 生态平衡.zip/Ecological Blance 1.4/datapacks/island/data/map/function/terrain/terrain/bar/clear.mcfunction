
execute on passengers on passengers on passengers on passengers run kill @s
execute on passengers on passengers on passengers run kill @s
execute on passengers on passengers if entity @s[type=interaction] run kill @s
execute as @e[tag=ride,tag=text] run function map:terrain/terrain/bar/clear0