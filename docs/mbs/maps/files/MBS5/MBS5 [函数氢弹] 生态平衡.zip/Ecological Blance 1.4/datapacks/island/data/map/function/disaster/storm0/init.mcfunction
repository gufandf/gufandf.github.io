
scoreboard players set #storm0 map.disaster 1
scoreboard players set #storm.timer map.disaster 0
scoreboard players add #storm.ebi map.disaster 1
function map:game/ending/6/init