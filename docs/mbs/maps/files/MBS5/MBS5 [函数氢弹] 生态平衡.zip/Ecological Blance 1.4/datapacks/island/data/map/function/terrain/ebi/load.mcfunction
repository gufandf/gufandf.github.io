
scoreboard objectives add ebi dummy
 scoreboard players set #speed0 ebi 40
 scoreboard players set #speed1 ebi 20
 scoreboard players set #speed2 ebi 10
 scoreboard players set #speed3 ebi 0

 scoreboard players set #stone ebi -4
 scoreboard players set #sand ebi -2
 scoreboard players set #grassland ebi 1
 scoreboard players set #grass ebi 1
 scoreboard players set #forest ebi 4
 scoreboard players set #forest_cut ebi 1
 scoreboard players set #farmland ebi -2
 scoreboard players set #farmland_sow ebi -4
 scoreboard players set #pigfarm ebi -2
 scoreboard players set #pigfarm_pig ebi -5
 scoreboard players set #ocean ebi 5
 scoreboard players set #bruh ebi 5
 scoreboard players set #vine ebi 2