
execute unless score @s system.quitgame = @s system.quitgame run function system:joingame
function system:uuid
function inventory:tick0
function map:tick0