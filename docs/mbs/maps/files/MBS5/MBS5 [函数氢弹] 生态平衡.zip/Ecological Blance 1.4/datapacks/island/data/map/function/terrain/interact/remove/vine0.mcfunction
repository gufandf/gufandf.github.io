
tellraw @s [{translate:island.tellraw.build.vine.0}]

function map:item/_get_item/resource/seed