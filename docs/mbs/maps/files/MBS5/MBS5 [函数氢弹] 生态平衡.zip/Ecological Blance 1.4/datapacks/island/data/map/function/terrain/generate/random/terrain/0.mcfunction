
#选开始位置
scoreboard players remove #size map.generate.stat 1
execute if score #size map.generate.stat matches 0.. positioned ~-1 ~ ~-1 run return run function map:terrain/generate/random/terrain/0
function map:terrain/generate/random/terrain/1