
tag @s add opened
tag @s add chosen
execute at @s run summon chest_minecart ~ ~ ~ {Tags:[terrain,minecart,menu,chosen,"interactable"],CustomName:[{text:""}],DisplayState:{Name:"barrier"},NoGravity:1b,LootTable:"map:nothing"}
ride @s mount @n[type=block_display,tag=terrain,tag=minecart,tag=menu,tag=ride]
team join collision @n[type=chest_minecart,tag=terrain,tag=minecart,tag=chosen]
scoreboard players operation @s map.terrain.menu.uuid = uuid map.terrain.menu.uuid
function map:terrain/terrain/menu/menu_item/menu1
tag @s remove chosen
