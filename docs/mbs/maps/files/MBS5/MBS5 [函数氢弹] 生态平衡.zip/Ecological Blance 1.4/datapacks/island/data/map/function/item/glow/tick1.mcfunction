
scoreboard players remove @s[scores={map.item.glow=-1..}] map.item.glow 1
execute if entity @s[scores={map.item.glow=1..}] run data modify entity @s Glowing set value 1b
execute if entity @s[scores={map.item.glow=0}] run data modify entity @s Glowing set value 0b