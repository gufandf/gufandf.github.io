
execute if score #amount.air map.generate.stat matches 1.. run scoreboard players set @s map.structure 0
execute if score #amount.air map.generate.stat matches 1.. run return run scoreboard players remove #amount.air map.generate.stat 1
