
function map:terrain/tick0
function map:item/tick0