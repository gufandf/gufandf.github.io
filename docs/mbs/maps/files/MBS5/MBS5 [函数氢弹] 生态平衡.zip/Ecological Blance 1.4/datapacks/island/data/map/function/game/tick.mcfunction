
time add 10
scoreboard players add #time map.game 10
execute if score #time map.game matches 24000.. run scoreboard players add #time.day map.game 1
execute if score #time map.game matches 24000.. as @a at @s run function map:game/day
execute if score #time map.game matches 24000.. run scoreboard players remove #time map.game 24000
scoreboard players operation time.day map.game = #time.day map.game
function map:game/ending/detect
execute if score #ending map.game.ending matches 1.. run function map:game/ending/tick
