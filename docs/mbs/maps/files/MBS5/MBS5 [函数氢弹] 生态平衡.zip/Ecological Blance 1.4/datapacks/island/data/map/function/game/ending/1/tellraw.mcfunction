
tellraw @s [{translate:island.tellraw.ending.0}]
tellraw @s [{translate:island.tellraw.ending1.0}]
tellraw @s [{translate:island.tellraw.ending1.1}]
tellraw @s [{translate:island.tellraw.ending1.2}]
tellraw @s [{translate:island.tellraw.ending1.3}]
tellraw @s [{translate:island.tellraw.ending.0}]