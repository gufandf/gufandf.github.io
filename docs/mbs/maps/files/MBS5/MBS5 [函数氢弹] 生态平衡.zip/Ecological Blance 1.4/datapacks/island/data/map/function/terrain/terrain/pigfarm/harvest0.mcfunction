#2..7
function map:item/_get_item/resource/porkchop
function map:item/_get_item/resource/porkchop
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.porkchop0 map.terrain.pigfarm run function map:item/_get_item/resource/porkchop
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.porkchop0 map.terrain.pigfarm run function map:item/_get_item/resource/porkchop
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.porkchop0 map.terrain.pigfarm run function map:item/_get_item/resource/porkchop
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.porkchop0 map.terrain.pigfarm run function map:item/_get_item/resource/porkchop
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.porkchop0 map.terrain.pigfarm run function map:item/_get_item/resource/porkchop