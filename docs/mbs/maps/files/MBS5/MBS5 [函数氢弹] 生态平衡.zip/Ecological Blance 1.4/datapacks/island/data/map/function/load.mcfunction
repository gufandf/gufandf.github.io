
function map:item/load
function map:game/load
function map:disaster/load

function map:terrain/load



team add collision
team modify collision collisionRule never
team add game.player
team modify game.player collisionRule never








