
scoreboard players set #range interaction.range 0
execute unless score @s interaction.right_click matches 0.. run scoreboard players set @s interaction.right_click 0
scoreboard players add @s interaction.right_click 1
execute if score @s interaction.right_click matches 1 run scoreboard players add @s interaction.right_click 1
execute if entity @n[type=interaction,tag=target] anchored eyes positioned ^ ^ ^ run function interaction:loop/0
function interaction:interact/click
tag @s remove chosen