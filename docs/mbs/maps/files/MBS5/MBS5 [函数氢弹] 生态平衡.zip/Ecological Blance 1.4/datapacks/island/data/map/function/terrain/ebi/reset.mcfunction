
data remove storage map operation