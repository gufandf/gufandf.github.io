
execute unless score @s map.terrain_timer > #time map.terrain.pigfarm run playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
execute unless score @s map.terrain_timer > #time map.terrain.pigfarm run return run tellraw @p[tag=chosen] [{translate:island.tellraw.build.pigfarm.2}]

execute as @p[tag=chosen] run function map:terrain/terrain/pigfarm/harvest0
scoreboard players set @s map.terrain_timer 0
execute on passengers on passengers if entity @s[type=item_display] run data modify entity @s item.components."minecraft:item_model" set value "island:pigfarm0"
function map:terrain/terrain/bar/clear

playsound entity.pig.death record @a ~ ~ ~ 2 1
tellraw @p[tag=chosen] [{translate:island.tellraw.build.pigfarm.3}]
execute at @s run particle block{block_state:redstone_block} ~ ~0.5 ~ 0.2 0.2 0.2 0.05 30 force @a
scoreboard players operation @s map.terrain_process += #change.pigfarm map.terrain_process
