
execute if score #end map.game.ending matches 1 run return fail
scoreboard players set #ending0 map.game.ending 3
function map:game/ending/end/0
schedule function map:game/ending/end/end 200t