
execute if data entity @s interaction.player run function interaction:detect/right_click
execute if data entity @s attack.player run function interaction:detect/left_click