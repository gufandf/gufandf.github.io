
tellraw @s [{translate:island.tellraw.ending.0}]
tellraw @s [{translate:island.tellraw.ending5.0}]
tellraw @s [{translate:island.tellraw.ending5.1}]
tellraw @s [{translate:island.tellraw.ending5.2}]
tellraw @s [{translate:island.tellraw.ending5.3}]
tellraw @s [{translate:island.tellraw.ending.0}]