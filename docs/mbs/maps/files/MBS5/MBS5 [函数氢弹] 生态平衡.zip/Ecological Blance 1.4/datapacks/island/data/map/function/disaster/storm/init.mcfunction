
scoreboard players set #storm map.disaster 1
scoreboard players set #storm.timer map.disaster 0
scoreboard players add #storm.ebi map.disaster 1