#
scoreboard players operation #max map.generate.stat = #grass.air map.generate.weight
scoreboard players operation #max map.generate.stat += #grass.grass map.generate.weight
scoreboard players operation #max map.generate.stat += #grass.forest map.generate.weight
scoreboard players operation #max map.generate.stat += #grass.house map.generate.weight
execute store result score #amount map.generate.stat run execute if entity @e[type=interaction,tag=terrain,scores={map.terrain=0}]

scoreboard players operation #amount.air map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.air map.generate.stat *= #grass.air map.generate.weight
scoreboard players operation #amount.air map.generate.stat /= #max map.generate.stat

scoreboard players operation #amount.grass map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.grass map.generate.stat *= #grass.grass map.generate.weight
scoreboard players operation #amount.grass map.generate.stat /= #max map.generate.stat

scoreboard players operation #amount.forest map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.forest map.generate.stat *= #grass.forest map.generate.weight
scoreboard players operation #amount.forest map.generate.stat /= #max map.generate.stat

execute as @e[type=interaction,tag=terrain,scores={map.terrain=0}] at @s run function map:terrain/generate/random/structure/1
#
scoreboard players operation #max map.generate.stat = #stone.air map.generate.weight
scoreboard players operation #max map.generate.stat += #stone.grass map.generate.weight
scoreboard players operation #max map.generate.stat += #stone.forest map.generate.weight
scoreboard players operation #max map.generate.stat += #stone.house map.generate.weight
execute store result score #amount map.generate.stat run execute if entity @e[type=interaction,tag=terrain,scores={map.terrain=1}]

scoreboard players operation #amount.air map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.air map.generate.stat *= #stone.air map.generate.weight
scoreboard players operation #amount.air map.generate.stat /= #max map.generate.stat

scoreboard players operation #amount.grass map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.grass map.generate.stat *= #stone.grass map.generate.weight
scoreboard players operation #amount.grass map.generate.stat /= #max map.generate.stat

scoreboard players operation #amount.forest map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.forest map.generate.stat *= #stone.forest map.generate.weight
scoreboard players operation #amount.forest map.generate.stat /= #max map.generate.stat

execute as @e[type=interaction,tag=terrain,scores={map.terrain=1}] at @s run function map:terrain/generate/random/structure/1
#
scoreboard players operation #max map.generate.stat = #sand.air map.generate.weight
scoreboard players operation #max map.generate.stat += #sand.grass map.generate.weight
scoreboard players operation #max map.generate.stat += #sand.forest map.generate.weight
scoreboard players operation #max map.generate.stat += #sand.house map.generate.weight
execute store result score #amount map.generate.stat run execute if entity @e[type=interaction,tag=terrain,scores={map.terrain=2}]

scoreboard players operation #amount.air map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.air map.generate.stat *= #sand.air map.generate.weight
scoreboard players operation #amount.air map.generate.stat /= #max map.generate.stat

scoreboard players operation #amount.grass map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.grass map.generate.stat *= #sand.grass map.generate.weight
scoreboard players operation #amount.grass map.generate.stat /= #max map.generate.stat

scoreboard players operation #amount.forest map.generate.stat = #amount map.generate.stat
scoreboard players operation #amount.forest map.generate.stat *= #sand.forest map.generate.weight
scoreboard players operation #amount.forest map.generate.stat /= #max map.generate.stat


execute as @e[type=interaction,tag=terrain,scores={map.terrain=2}] at @s run function map:terrain/generate/random/structure/1
execute positioned 16 4 16 as @n[type=interaction,tag=terrain,distance=0.1..,scores={map.structure=0}] at @s run return run scoreboard players set @s map.structure 3
execute positioned 16 4 16 as @n[type=interaction,tag=terrain,distance=0.1..,scores={map.structure=0..}] at @s run return run scoreboard players set @s map.structure 3