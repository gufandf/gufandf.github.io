
tellraw @s [{translate:island.tellraw.build.farmland.5}]

function map:item/_get_item/resource/seed
