
scoreboard players set @s system.quitgame 0
