
execute on passengers on passengers if entity @s[type=block_display,tag=vine] run scoreboard players operation #glow map.generate.stat = @s map.item.glow
scoreboard players operation #value map.generate.stat = @s map.terrain_timer0
scoreboard players operation #max map.generate.stat = #time map.terrain.vine
execute if score #glow map.generate.stat matches -1 run function map:terrain/terrain/bar/clear
execute unless entity @e[type=interaction,scores={map.terrain=0..2,map.vine=0},distance=0.1..1.5] if score @s map.terrain matches 0 run return run scoreboard players set @s map.terrain_timer0 0
execute if score #glow map.generate.stat matches 1.. run function map:terrain/terrain/bar/0
execute unless score @s map.terrain_timer0 > #time map.terrain.vine run return run scoreboard players add @s map.terrain_timer0 1
execute unless score @s map.terrain_timer0 > #time map.terrain.vine run return run scoreboard players operation @s map.terrain_timer0 += #vine map.terrain
scoreboard players set @s map.terrain_timer0 0
execute if score @s map.terrain matches 1..2 run return run function map:terrain/terrain/vine/spread
execute as @e[type=interaction,scores={map.terrain=0..2,map.vine=0},distance=..1.5] run return run function map:terrain/terrain/vine/spread
