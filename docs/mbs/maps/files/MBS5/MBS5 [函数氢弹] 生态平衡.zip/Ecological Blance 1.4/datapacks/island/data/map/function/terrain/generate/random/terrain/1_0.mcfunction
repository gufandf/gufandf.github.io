
scoreboard players add #i map.generate.stat 1
scoreboard players set #i0 map.generate.stat 0
function map:terrain/generate/random/terrain/1_1
execute if score #i map.generate.stat < #loop map.generate.stat positioned ~1 ~ ~ run return run function map:terrain/generate/random/terrain/1_0
