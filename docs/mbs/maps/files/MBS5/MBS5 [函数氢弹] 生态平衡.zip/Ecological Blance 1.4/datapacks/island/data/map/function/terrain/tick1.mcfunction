
execute unless score @s map.structure0 = @s map.structure at @s run function map:terrain/tick1_structure
execute unless score @s map.terrain0 = @s map.terrain at @s positioned ~ ~-1 ~ run function map:terrain/tick1_terrain
execute unless score @s map.vine0 = @s map.vine at @s run function map:terrain/tick1_vine
execute if score @s map.terrain_process >= #change map.terrain_process at @s run function map:terrain/tick1_process

execute if score @s map.vine matches 1 at @s run return run function map:terrain/terrain/vine/tick
execute if score @s map.structure matches 2 at @s run return run function map:terrain/terrain/forest/tick
execute if score @s map.structure matches 3 at @s run return run function map:terrain/terrain/house/tick
execute if score @s map.structure matches 4 at @s run return run function map:terrain/terrain/farmland/tick
execute if score @s map.structure matches 5 at @s run return run function map:terrain/terrain/pigfarm/tick
execute if score @s map.structure matches 7 at @s run return run function map:terrain/terrain/regrasser/tick
