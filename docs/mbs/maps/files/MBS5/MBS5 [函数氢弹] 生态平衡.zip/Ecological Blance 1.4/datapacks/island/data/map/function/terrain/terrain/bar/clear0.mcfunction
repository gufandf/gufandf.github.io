
execute on vehicle if entity @s run return fail
kill @s