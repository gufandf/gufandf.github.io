
function map:terrain/generate/reset