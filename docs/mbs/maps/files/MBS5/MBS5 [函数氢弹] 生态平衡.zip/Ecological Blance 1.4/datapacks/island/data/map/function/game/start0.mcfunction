
team join game.player @s
clear @s
tp @s 16 3 24 180 0
function map:terrain/generate/random/start
function inventory:inventory/start