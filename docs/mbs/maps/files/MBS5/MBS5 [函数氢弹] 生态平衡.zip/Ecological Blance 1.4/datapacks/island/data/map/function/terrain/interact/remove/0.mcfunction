
execute if score @s map.structure matches 0 unless score @s map.vine matches 1 run playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
execute if score @s map.structure matches 0 unless score @s map.vine matches 1 run return run tellraw @p[tag=chosen] [{translate:island.tellraw.remove.1}]

execute store result score #wheat map.generate.stat run execute if items entity @p[tag=chosen] container.* *[custom_data~{tag:[wheat]}]
execute if score #wheat map.generate.stat < #remove.wheat map.item run playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
execute if score #wheat map.generate.stat < #remove.wheat map.item run return run tellraw @p[tag=chosen] [{translate:island.tellraw.remove.0,with:[{score:{name:"#wheat",objective:map.generate.stat}},{score:{name:"#remove.wheat",objective:map.item}}]}]

clear @p[tag=chosen] *[custom_data~{tag:[wheat]}] 3
execute if score @s map.vine matches 1 run return run function map:terrain/interact/remove/vine
execute if score @s map.structure matches 1 run function map:terrain/interact/remove/grass
execute if score @s map.structure matches 2 run function map:terrain/interact/remove/forest
execute if score @s map.structure matches 3 run function map:terrain/interact/remove/house
execute if score @s map.structure matches 4 run function map:terrain/interact/remove/farmland
execute if score @s map.structure matches 5 run function map:terrain/interact/remove/pigfarm
function map:terrain/interact/remove/terrain
scoreboard players set @s map.structure 0
scoreboard players set @s map.terrain_process 0
execute on passengers run function system:death
data modify entity @s height set value 0.0125
