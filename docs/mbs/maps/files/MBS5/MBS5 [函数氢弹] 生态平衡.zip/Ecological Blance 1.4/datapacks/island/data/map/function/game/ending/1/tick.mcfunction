
scoreboard players operation #timer map.game -= #ebi0 ebi
execute if score #timer map.game matches ..0 run scoreboard players set #ending map.game.ending 0
execute if score #timer map.game matches ..0 run scoreboard players set #timer0 map.game 0
execute if score #timer map.game matches ..0 run return run scoreboard players set #timer map.game 0

execute if score #timer map.game matches 150.. store result score #random map.game run random value 0..2
scoreboard players operation #timer0 map.game += #random map.game
execute if score #timer map.game matches 1000.. store result score #random map.game run random value 2..10
scoreboard players operation #timer0 map.game += #random map.game
execute if score #timer map.game matches 5000.. store result score #random map.game run random value 4..20
scoreboard players operation #timer0 map.game += #random map.game
execute if score #timer map.game matches 10000.. store result score #random map.game run random value 10..50
scoreboard players operation #timer0 map.game += #random map.game
execute if score #timer map.game matches 50000.. run scoreboard players set #random map.game 100
scoreboard players operation #timer0 map.game += #random map.game
execute unless score #timer0 map.game matches 100.. run return fail
execute unless entity @e[type=interaction,tag=generate,scores={map.terrain=0}] run function map:game/ending/1/end

scoreboard players remove #timer0 map.game 100
execute as @e[type=interaction,tag=generate,scores={map.terrain=1},sort=random,limit=1] at @s as @e[sort=random,limit=1,type=interaction,tag=generate,scores={map.terrain=0}] run return run scoreboard players set @s map.terrain 2
execute as @e[type=interaction,tag=generate,scores={map.terrain=1},sort=random,limit=1] at @s as @e[sort=random,limit=1,type=interaction,tag=generate,scores={map.terrain=3..6}] run scoreboard players set @s map.terrain 2
execute as @e[type=interaction,tag=generate,scores={map.terrain=1},sort=random,limit=1] at @s as @e[sort=random,limit=1,type=interaction,tag=generate,scores={map.terrain=2}] run scoreboard players set @s map.terrain 1
execute as @e[type=interaction,tag=generate,scores={map.terrain=1},sort=random,limit=1] at @s as @e[sort=random,limit=1,type=interaction,tag=generate,scores={map.terrain=2}] run return run scoreboard players set @s map.terrain 1
execute as @e[type=interaction,tag=generate,scores={map.terrain=1},sort=random,limit=1] at @s as @e[sort=random,limit=1,type=interaction,tag=generate,scores={map.terrain=3..6}] run scoreboard players set @s map.terrain 2
execute as @e[type=interaction,tag=generate,scores={map.terrain=1},sort=random,limit=1] at @s as @e[sort=random,limit=1,type=interaction,tag=generate,scores={map.terrain=3..6}] run return run scoreboard players set @s map.terrain 2
execute as @e[type=interaction,tag=generate,scores={map.terrain=2},sort=random,limit=1] run return run scoreboard players set @s map.terrain 1
execute as @e[type=interaction,tag=generate,scores={map.terrain=0},sort=random,limit=1] run return run scoreboard players set @s map.terrain 2