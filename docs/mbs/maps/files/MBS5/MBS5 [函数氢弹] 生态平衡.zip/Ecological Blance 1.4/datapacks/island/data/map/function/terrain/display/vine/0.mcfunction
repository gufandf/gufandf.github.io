
summon block_display ~ ~ ~ {Tags:[terrain,vine,display,chosen],block_state:{Name:vine}}
data modify entity @n[type=block_display,tag=chosen] transformation.translation set value [-0.375,-0.25,-0.375]
data modify entity @n[type=block_display,tag=chosen] transformation.scale set value [0.75,0.75,0.75]
execute on passengers if entity @s[tag=position_fix] run ride @n[type=block_display,tag=chosen] mount @s
tag @e[tag=chosen] remove chosen
scoreboard players set @s map.terrain_timer0 0