
execute as @p[tag=chosen] run function map:terrain/interact/remove/farmland0
particle cloud ~ ~ ~ 0.2 0.2 0.2 0.05 5 force @a
playsound item.shield.break record @a ~ ~ ~ 2 1
