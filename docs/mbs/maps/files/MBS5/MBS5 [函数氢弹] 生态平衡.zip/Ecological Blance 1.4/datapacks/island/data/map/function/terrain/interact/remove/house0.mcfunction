
tellraw @s [{text:"你为什么要这么做 你把你的小屋拆了"}]

execute as @e[tag=terrain,tag=minecart] run function system:death
particle cloud ~ ~ ~ 0.2 0.2 0.2 0.05 5 force @a
playsound item.totem.use record @a ~ ~ ~ 2 0
