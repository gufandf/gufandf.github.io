
scoreboard objectives remove interaction.state

scoreboard objectives remove interaction.range

scoreboard objectives remove interaction.right_click
scoreboard objectives remove interaction.right_click0
scoreboard objectives remove interaction.left_click