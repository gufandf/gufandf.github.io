
execute if items entity @p[tag=chosen] weapon.* *[custom_data~{tag:[build]}] at @s run return run function map:terrain/interact/build/0
execute if items entity @p[tag=chosen] weapon.* *[custom_data~{tag:[remove]}] run return run function map:terrain/interact/remove/0


execute if score @s map.structure matches 1.. if score @s map.vine matches 1 run return run function map:terrain/terrain/vine/rightclick
execute if score @s map.structure matches 2 run return run function map:terrain/terrain/forest/rightclick
execute if score @s map.structure matches 4 run return run function map:terrain/terrain/farmland/rightclick
execute if score @s map.structure matches 5 run return run function map:terrain/terrain/pigfarm/rightclick
