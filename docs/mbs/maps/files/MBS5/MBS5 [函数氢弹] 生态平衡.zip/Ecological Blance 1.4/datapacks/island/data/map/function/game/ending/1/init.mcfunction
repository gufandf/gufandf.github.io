
scoreboard players set #ending map.game.ending 1
scoreboard players set #timer map.game.ending 0
scoreboard players set #timer0 map.game 0