
scoreboard players operation limit inventory.slot_limit = @s inventory.slot_limit