
scoreboard objectives add map.terrain.forest dummy
 scoreboard players set #time map.terrain.forest 200
 scoreboard players set #chance.wood0 map.terrain.forest 25