
execute on passengers on passengers if entity @s[type=item_display] run scoreboard players operation #glow map.generate.stat = @s map.item.glow
scoreboard players operation #value map.generate.stat = @s map.terrain_timer
scoreboard players operation #max map.generate.stat = #time map.terrain.regrasser
execute if score #glow map.generate.stat matches 1.. run function map:terrain/terrain/bar/0
execute if score #glow map.generate.stat matches -1 run function map:terrain/terrain/bar/clear
execute unless score @s map.terrain_timer > #time map.terrain.regrasser run return run scoreboard players add @s map.terrain_timer 1
execute if score #value map.generate.stat matches 1.. run scoreboard players set @s map.structure 0
execute if score #value map.generate.stat matches 1.. if score @s map.terrain matches 0 run scoreboard players set @s map.structure 2
execute if score #value map.generate.stat matches 1.. if score @s map.terrain matches 2 run scoreboard players set @s map.terrain 0
execute if score #value map.generate.stat matches 1.. if score @s map.terrain matches 1 run scoreboard players set @s map.terrain 2