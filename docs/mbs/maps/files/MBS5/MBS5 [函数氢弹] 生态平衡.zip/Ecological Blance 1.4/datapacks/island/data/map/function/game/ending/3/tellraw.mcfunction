
tellraw @s [{translate:island.tellraw.ending.0}]
tellraw @s [{translate:island.tellraw.ending3.0}]
tellraw @s [{translate:island.tellraw.ending3.1}]
tellraw @s [{translate:island.tellraw.ending3.2}]
tellraw @s [{translate:island.tellraw.ending3.3}]
tellraw @s [{translate:island.tellraw.ending.0}]