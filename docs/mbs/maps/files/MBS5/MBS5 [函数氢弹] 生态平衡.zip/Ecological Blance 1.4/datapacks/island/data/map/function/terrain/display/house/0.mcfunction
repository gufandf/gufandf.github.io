
summon interaction ~ ~ ~ {Tags:[position_fix,ride,chosen],width:0,height:-0.0125,Passengers:[\
{id:item_display,Tags:[terrain,display,chosen],item:{id:"diamond",components:{item_model:"island:house"}}}]}
data modify entity @n[type=item_display,tag=chosen] transformation.translation set value [0.0,0.5,0.0]
ride @n[type=interaction,tag=chosen] mount @s
tag @e[tag=chosen] remove chosen
data modify entity @s height set value 0.0125
function map:terrain/terrain/menu/0
scoreboard players set @s map.terrain_timer 0