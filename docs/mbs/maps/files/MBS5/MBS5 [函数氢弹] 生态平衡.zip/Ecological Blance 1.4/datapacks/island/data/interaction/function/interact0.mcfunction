
execute if entity @s[type=interaction] run return run function interaction:tick1_0
execute on attacker run say 1