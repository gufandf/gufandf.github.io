
clear @s *[custom_data~{tag:[wood]}] 5
clear @s *[custom_data~{tag:[seed]}] 5
 function map:item/_get_item/build/farmland
tag @s remove target