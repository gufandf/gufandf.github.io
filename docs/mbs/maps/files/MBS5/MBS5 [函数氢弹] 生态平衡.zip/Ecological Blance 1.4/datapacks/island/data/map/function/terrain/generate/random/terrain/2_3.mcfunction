
execute as @e[type=interaction,tag=terrain,scores={map.terrain=0..}] at @s run setblock ~ ~ ~ air
return fail
execute as @e[type=interaction,tag=terrain,scores={map.terrain=0..}] at @s unless score @s map.terrain matches 3..6 unless entity @e[type=interaction,tag=terrain,scores={map.terrain=3..6},distance=0.01..1] run tag @s add chosen
execute as @e[type=interaction,tag=terrain,scores={map.terrain=3..6}] at @s if score @s map.terrain matches 3..6 unless score @s map.terrain matches 5 run scoreboard players set @s map.terrain 4
execute as @e[type=interaction,tag=terrain,scores={map.terrain=3..6}] at @s if score @s map.terrain matches 4 at @s unless entity @e[type=interaction,tag=terrain,scores={map.terrain=4},distance=0.01..1] run scoreboard players set @s map.terrain 5

execute unless entity @e[type=interaction,tag=terrain,scores={map.terrain=5}] run scoreboard players set @e[type=interaction,tag=chosen,limit=1,sort=random] map.terrain 5
tag @e[tag=chosen] remove chosen
