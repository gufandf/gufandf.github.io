
$title @a actionbar [{translate:island.actionbar.ebi},{score:{name:"#ebi0",objective:ebi},color:"$(output)"}]
