
kill @e[tag=terrain,tag=text]
execute as @e[type=interaction,tag=generate,tag=terrain] at @s run function system:death
function map:terrain/generate/random/terrain/start
function map:terrain/generate/random/structure/start

function map:terrain/ebi/calculate/start
scoreboard players operation #ebi0 ebi = #ebi ebi