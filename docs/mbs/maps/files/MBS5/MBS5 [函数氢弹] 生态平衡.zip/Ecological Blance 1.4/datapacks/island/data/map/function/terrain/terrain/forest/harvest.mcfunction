
execute unless score @s map.terrain_timer > #time map.terrain.forest run playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
execute unless score @s map.terrain_timer > #time map.terrain.forest run return run tellraw @p[tag=chosen] [{translate:island.tellraw.build.forest.0}]

execute as @p[tag=chosen] run function map:terrain/terrain/forest/harvest0
execute on passengers on passengers if entity @s[type=item_display] run data modify entity @s item.components."minecraft:item_model" set value "island:forest0"
scoreboard players set @s map.terrain_timer 0

playsound entity.item.pickup record @a ~ ~ ~ 1 1
tellraw @p[tag=chosen] [{translate:island.tellraw.build.forest.2}]
execute at @s run particle crit ~ ~0.5 ~ 0.2 0.2 0.2 0.05 10 force @a
scoreboard players operation @s map.terrain_process += #change.forest map.terrain_process