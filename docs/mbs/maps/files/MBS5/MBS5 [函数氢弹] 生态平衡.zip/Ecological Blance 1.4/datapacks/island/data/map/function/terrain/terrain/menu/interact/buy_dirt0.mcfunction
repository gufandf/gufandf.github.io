
clear @s *[custom_data~{tag:[wood]}] 10
clear @s *[custom_data~{tag:[porkchop]}] 4
clear @s *[custom_data~{tag:[wheat]}] 5
clear @s *[custom_data~{tag:[seed]}] 8
 function map:item/_get_item/build/dirt
tag @s remove target