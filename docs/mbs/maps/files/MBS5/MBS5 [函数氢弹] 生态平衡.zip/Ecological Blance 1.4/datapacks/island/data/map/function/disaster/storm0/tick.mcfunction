
scoreboard players add @e[scores={map.structure=4,map.terrain_timer=1..200}] map.terrain_timer 1
scoreboard players add @e[scores={map.structure=2,map.terrain_timer=1..200}] map.terrain_timer 1
execute positioned 16 8 16 run particle campfire_cosy_smoke ~ ~ ~ 2 0 2 0 10 force @a
scoreboard players add #storm0.timer map.disaster 1
execute if score #storm0.timer map.disaster matches 40 run weather thunder
execute if score #storm0.timer map.disaster matches 40.. positioned 16 8 16 run particle rain ~ ~ ~ 1 0 1 0 5 force @a
execute if score #storm0.timer map.disaster matches 60 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 90 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 120 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 140 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 160 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 180 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 190 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 200 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 205 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 210 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 215 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 217 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 219 run function map:disaster/storm0/chose
execute if score #storm0.timer map.disaster matches 225.. run function map:disaster/storm0/chose
execute as @e[type=interaction,tag=terrain,scores={map.storm0=1..}] at @s run function map:disaster/storm0/tick0
execute if score #storm0.timer map.disaster <= #storm0.time map.disaster run return fail

function map:disaster/storm0/end