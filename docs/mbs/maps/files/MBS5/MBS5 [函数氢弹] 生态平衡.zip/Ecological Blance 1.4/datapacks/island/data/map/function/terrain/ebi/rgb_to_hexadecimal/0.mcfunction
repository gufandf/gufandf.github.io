##颜色RGB转16进制

scoreboard players operation #temp11 ebi = #rgb.R ebi
scoreboard players operation #temp2 ebi = #rgb.G ebi
scoreboard players operation #temp11 ebi *= #65536 number
scoreboard players operation #temp2 ebi *= #256 number
scoreboard players operation #temp11 ebi += #temp2 ebi
execute store result score #temp12 ebi run scoreboard players operation #temp11 ebi += #rgb.B ebi

execute store result score #temp13 ebi run scoreboard players operation #temp12 ebi /= #16 number
execute store result score #temp14 ebi run scoreboard players operation #temp13 ebi /= #16 number
execute store result score #temp15 ebi run scoreboard players operation #temp14 ebi /= #16 number
execute store result score #temp16 ebi run scoreboard players operation #temp15 ebi /= #16 number
scoreboard players operation #temp16 ebi /= #16 number

data modify storage map root.temp1 set value [{a:0},{a:0},{a:0},{a:0},{a:0},{a:0}]
execute store result storage map root.temp1[0].a int 1 run scoreboard players operation #temp16 ebi %= #16 number
execute store result storage map root.temp1[1].a int 1 run scoreboard players operation #temp15 ebi %= #16 number
execute store result storage map root.temp1[2].a int 1 run scoreboard players operation #temp14 ebi %= #16 number
execute store result storage map root.temp1[3].a int 1 run scoreboard players operation #temp13 ebi %= #16 number
execute store result storage map root.temp1[4].a int 1 run scoreboard players operation #temp12 ebi %= #16 number
execute store result storage map root.temp1[5].a int 1 run scoreboard players operation #temp11 ebi %= #16 number

data modify storage map root.temp1[{a:10}].a set value "a"
data modify storage map root.temp1[{a:11}].a set value "b"
data modify storage map root.temp1[{a:12}].a set value "c"
data modify storage map root.temp1[{a:13}].a set value "d"
data modify storage map root.temp1[{a:14}].a set value "e"
data modify storage map root.temp1[{a:15}].a set value "f"

data modify storage map root.stemp0 set from storage map root.temp1[0].a
data modify storage map root.stemp1 set from storage map root.temp1[1].a
data modify storage map root.stemp2 set from storage map root.temp1[2].a
data modify storage map root.stemp3 set from storage map root.temp1[3].a
data modify storage map root.stemp4 set from storage map root.temp1[4].a
data modify storage map root.stemp5 set from storage map root.temp1[5].a

function map:terrain/ebi/rgb_to_hexadecimal/1 with storage map root
data remove storage map root