
execute as @p[tag=chosen] run function map:terrain/interact/remove/grass0

particle cloud ~ ~ ~ 0.2 0.2 0.2 0.05 5 force @a
playsound block.rooted_dirt.break record @a ~ ~ ~ 2 0
playsound block.rooted_dirt.break record @a ~ ~ ~ 2 0
playsound block.rooted_dirt.break record @a ~ ~ ~ 2 0
