
execute as @e[tag=terrain,tag=minecart] run function system:death
summon chest_minecart ~ ~0.25 ~ {Tags:[terrain,minecart,menu,chosen,"interactable"],CustomName:[{text:""}],DisplayState:{Name:"barrier"},NoGravity:1b,LootTable:"map:nothing"}
summon block_display ~ ~-1 ~ {Tags:[terrain,minecart,menu,ride]}
team join collision @n[type=chest_minecart,tag=collision,tag=chosen]
tag @e[tag=chosen] remove chosen