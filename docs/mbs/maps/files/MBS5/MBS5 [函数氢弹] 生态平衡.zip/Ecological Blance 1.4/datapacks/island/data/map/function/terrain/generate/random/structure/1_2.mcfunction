
execute if score #amount.forest map.generate.stat matches 1.. run scoreboard players set @s map.structure 2
execute if score #amount.forest map.generate.stat matches 1.. run return run scoreboard players remove #amount.forest map.generate.stat 1
