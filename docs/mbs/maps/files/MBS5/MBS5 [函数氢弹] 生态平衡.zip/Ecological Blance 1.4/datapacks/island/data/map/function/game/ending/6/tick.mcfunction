
scoreboard players add #timer map.game 1
execute unless score #timer map.game matches 300.. run return fail
function map:game/ending/6/end