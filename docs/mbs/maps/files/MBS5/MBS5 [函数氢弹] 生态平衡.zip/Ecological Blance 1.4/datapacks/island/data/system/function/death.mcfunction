
#particle cloud ~ ~0.25 ~ 0.25 0.5 0.25 0 30 normal @a
data modify entity @s Size set value 0
data modify entity @s Items set value []
tp @s[tag=!deathanimation] 0.0 -100.0 0.0
execute on passengers on passengers on passengers on passengers on passengers run kill @s
execute on passengers on passengers on passengers on passengers run kill @s
execute on passengers on passengers on passengers run kill @s
execute on passengers on passengers run kill @s
execute on passengers run kill @s
kill @s
