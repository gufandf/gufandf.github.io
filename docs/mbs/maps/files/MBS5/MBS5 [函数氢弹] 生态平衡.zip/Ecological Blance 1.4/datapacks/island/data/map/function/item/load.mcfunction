
scoreboard objectives add map.item dummy
scoreboard objectives add map.item.glow dummy

 scoreboard players set #remove.wheat map.item 3