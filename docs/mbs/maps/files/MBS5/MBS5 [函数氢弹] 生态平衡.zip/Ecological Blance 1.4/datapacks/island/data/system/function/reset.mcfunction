
gamemode adventure @a
difficulty peaceful
clear @a
scoreboard players reset *
team leave @a
stopsound @a
execute as @e[type=!player] run function system:death
effect give @a resistance infinite 4 true
effect give @a regeneration infinite 0 true
effect give @a saturation infinite 0 true
execute as @a run tp @s -24 1 -17 90 0
function interaction:reset