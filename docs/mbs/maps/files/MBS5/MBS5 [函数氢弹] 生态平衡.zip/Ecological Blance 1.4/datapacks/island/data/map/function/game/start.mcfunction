
time set 0
scoreboard players set #time map.game 0
scoreboard players set #tick map.game 1
scoreboard players set #time.day map.game 0
scoreboard players set #ending0 map.game.ending 0
scoreboard players set #storm.ebi map.disaster 0
execute as @a run function map:game/start0
function map:game/text