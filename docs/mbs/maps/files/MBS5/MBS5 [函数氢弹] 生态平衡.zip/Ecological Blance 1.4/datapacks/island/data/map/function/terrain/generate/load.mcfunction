
scoreboard objectives add map.generate dummy
scoreboard objectives add map.generate.weight dummy
 scoreboard players set #size map.generate.weight 4
 scoreboard players set #grass map.generate.weight 15
 scoreboard players set #stone map.generate.weight 2
 scoreboard players set #sand map.generate.weight 2
 scoreboard players set #water map.generate.weight 0
 scoreboard players set #seawater map.generate.weight 0
 scoreboard players set #freshwater map.generate.weight 2
 scoreboard players set #seawater0 map.generate.weight 20

 scoreboard players set #grass.air map.generate.weight 30
 scoreboard players set #grass.grass map.generate.weight 30
 scoreboard players set #grass.forest map.generate.weight 30

 scoreboard players set #stone.air map.generate.weight 3

 scoreboard players set #sand.air map.generate.weight 3

scoreboard objectives add map.generate.stat dummy