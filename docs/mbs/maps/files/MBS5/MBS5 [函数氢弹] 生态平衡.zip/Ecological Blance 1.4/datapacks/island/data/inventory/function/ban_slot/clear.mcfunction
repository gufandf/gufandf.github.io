
$clear @s *[custom_data~{tag:["ban_slot","$(slot)"]}]