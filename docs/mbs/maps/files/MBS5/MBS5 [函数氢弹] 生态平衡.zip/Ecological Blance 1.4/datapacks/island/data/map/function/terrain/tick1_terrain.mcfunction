
#0:草地 1:石头 2:沙子 3:水 4:海水 5:淡水 5:替换海水
scoreboard players operation @s map.terrain0 = @s map.terrain

execute if score @s map.terrain matches 3..6 run scoreboard players set @s map.terrain 5

execute if score @s map.terrain matches 0 run setblock ~ ~ ~ lime_wool
execute if score @s map.terrain matches 1 run setblock ~ ~ ~ light_gray_wool
execute if score @s map.terrain matches 2 run setblock ~ ~ ~ yellow_wool
#execute if score @s map.terrain matches 3 run setblock ~ ~ ~ white_wool
#execute if score @s map.terrain matches 4 run setblock ~ ~ ~ blue_wool
#execute if score @s map.terrain matches 5 run setblock ~ ~ ~ light_blue_wool
execute if score @s map.terrain matches 3 run setblock ~ ~ ~ barrier[waterlogged=true]
execute if score @s map.terrain matches 4 run setblock ~ ~ ~ barrier[waterlogged=true]
execute if score @s map.terrain matches 5 run setblock ~ ~ ~ barrier[waterlogged=true]
execute if score @s map.terrain matches 6 run setblock ~ ~ ~ barrier[waterlogged=true]

execute if score @s map.terrain matches 7 run setblock ~ ~ ~ lime_wool
execute if score @s map.terrain matches 8 run setblock ~ ~ ~ lime_wool
execute if score @s map.terrain matches 9 run setblock ~ ~ ~ lime_wool


execute if score @s map.terrain matches 1 if score @s map.structure matches 3 as @e[tag=terrain,tag=minecart] run function system:death
execute if score @s map.terrain matches 1 run scoreboard players set @s map.structure 0
execute if score @s map.terrain matches 2 unless score @s map.structure matches 3..5 run scoreboard players set @s map.structure 0