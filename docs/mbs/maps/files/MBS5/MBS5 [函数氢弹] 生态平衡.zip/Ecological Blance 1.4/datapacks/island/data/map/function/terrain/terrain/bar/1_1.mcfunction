

$data modify entity @s CustomName set value [{text:"§7["},{text:"§a$(2)§r"},{text:"§8$(3)§r"},{text:"§7]"}]
