
clear @s *[custom_data~{tag:[wood]}] 10
clear @s *[custom_data~{tag:[wheat]}] 40
clear @s *[custom_data~{tag:[porkchop]}] 10
clear @s *[custom_data~{tag:[seed]}] 40
 function map:item/_get_item/build/bruh
tag @s remove target