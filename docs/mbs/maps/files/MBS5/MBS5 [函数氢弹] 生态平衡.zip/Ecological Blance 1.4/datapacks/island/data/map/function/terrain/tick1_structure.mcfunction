
#0:空气 1:草 2:树 3:房子
scoreboard players operation @s map.structure0 = @s map.structure
function map:terrain/terrain/bar/clear
execute on passengers on passengers run kill @s
execute on passengers run kill @s
execute if score @s map.structure matches 0 run function map:terrain/display/air/0
execute if score @s map.structure matches 1 run function map:terrain/display/grass/0
execute if score @s map.structure matches 2 run function map:terrain/display/forest/0
execute if score @s map.structure matches 3 run scoreboard players set @s map.terrain 0
execute if score @s map.structure matches 3 run function map:terrain/display/house/0
execute if score @s map.structure matches 4 run function map:terrain/display/farmland/0
execute if score @s map.structure matches 5 run function map:terrain/display/pigfarm/0
execute if score @s map.structure matches 6 run scoreboard players set @s map.terrain 0
execute if score @s map.structure matches 6 run scoreboard players set @s map.structure 0
execute if score @s map.structure matches 7 run function map:terrain/display/regrasser/0
execute if score @s map.structure matches 8 run function map:terrain/display/bruh/0

