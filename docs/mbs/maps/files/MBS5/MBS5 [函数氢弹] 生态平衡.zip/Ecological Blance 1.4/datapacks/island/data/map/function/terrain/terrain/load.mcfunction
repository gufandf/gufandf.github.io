

function map:terrain/terrain/forest/load
function map:terrain/terrain/farmland/load
function map:terrain/terrain/pigfarm/load
function map:terrain/terrain/bar/load
function map:terrain/terrain/menu/load
function map:terrain/terrain/regrasser/load
function map:terrain/terrain/vine/load
