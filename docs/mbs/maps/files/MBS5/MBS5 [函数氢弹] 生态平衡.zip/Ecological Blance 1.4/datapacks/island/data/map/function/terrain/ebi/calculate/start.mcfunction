
scoreboard players set #ebi ebi 0
function map:terrain/ebi/calculate/0
