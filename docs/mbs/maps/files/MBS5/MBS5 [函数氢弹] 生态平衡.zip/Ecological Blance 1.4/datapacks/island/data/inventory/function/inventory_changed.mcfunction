

function inventory:ban_slot/detect

advancement revoke @s only inventory:inventory_changed