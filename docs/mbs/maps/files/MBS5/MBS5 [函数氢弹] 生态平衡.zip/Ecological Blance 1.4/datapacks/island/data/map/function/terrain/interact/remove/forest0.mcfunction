
tellraw @s [{translate:island.tellraw.build.forest.1}]

function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
