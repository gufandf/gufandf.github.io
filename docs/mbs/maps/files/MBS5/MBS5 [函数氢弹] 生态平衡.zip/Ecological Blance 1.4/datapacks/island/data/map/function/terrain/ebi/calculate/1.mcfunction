
execute if score @s map.terrain matches 0 run scoreboard players operation #ebi ebi += #grassland ebi
execute if score @s map.terrain matches 1 run scoreboard players operation #ebi ebi += #stone ebi
execute if score @s map.terrain matches 2 run scoreboard players operation #ebi ebi += #sand ebi
execute if score @s map.terrain matches 3..6 run scoreboard players operation #ebi ebi += #ocean ebi

execute if score @s map.vine matches 1 run scoreboard players operation #ebi ebi += #vine ebi

execute if score @s map.structure matches 1 run scoreboard players operation #ebi ebi += #grass ebi
execute if score @s map.structure matches 2 if score @s map.terrain_timer >= #time map.terrain.forest run scoreboard players operation #ebi ebi += #forest ebi
execute if score @s map.structure matches 2 unless score @s map.terrain_timer >= #time map.terrain.forest run scoreboard players operation #ebi ebi += #forest_cut ebi
execute if score @s map.structure matches 4 if score @s map.terrain_timer matches 1.. run scoreboard players operation #ebi ebi += #farmland_sow ebi
execute if score @s map.structure matches 4 unless score @s map.terrain_timer matches 1.. run scoreboard players operation #ebi ebi += #farmland ebi
execute if score @s map.structure matches 5 if score @s map.terrain_timer matches 1.. run scoreboard players operation #ebi ebi += #pigfarm_pig ebi
execute if score @s map.structure matches 5 unless score @s map.terrain_timer matches 1.. run scoreboard players operation #ebi ebi += #pigfarm ebi
execute if score @s map.structure matches 8 unless score @s map.terrain_timer matches 1.. run scoreboard players operation #ebi ebi += #bruh ebi