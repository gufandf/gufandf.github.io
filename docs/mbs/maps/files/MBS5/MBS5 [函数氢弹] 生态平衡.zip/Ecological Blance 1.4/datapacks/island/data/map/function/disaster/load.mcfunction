
scoreboard objectives add map.disaster dummy
 scoreboard players set #storm.time map.disaster 300
 scoreboard players set #storm0.time map.disaster 10000
scoreboard objectives add map.storm dummy
scoreboard objectives add map.storm0 dummy