
clear @s *[custom_data~{tag:[wood]}] 8
clear @s *[custom_data~{tag:[wheat]}] 5
 function map:item/_get_item/build/pigfarm
tag @s remove target