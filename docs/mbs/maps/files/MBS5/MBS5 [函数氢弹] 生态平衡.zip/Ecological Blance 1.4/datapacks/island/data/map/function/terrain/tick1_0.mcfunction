
scoreboard players add @s map.terrain_timer 1
execute if score @s map.terrain_timer matches ..20 run return fail
function system:death