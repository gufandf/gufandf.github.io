
scoreboard objectives add map.terrain.pigfarm dummy
 scoreboard players set #time map.terrain.pigfarm 200
 scoreboard players set #wheat map.terrain.pigfarm 2
 scoreboard players set #chance.porkchop0 map.terrain.pigfarm 50