
$data modify entity @s data.text.2 set string storage bar text 0 $(0)
$data modify entity @s data.text.3 set string storage bar text 0 $(1)

