
$data modify storage map operation.output set value "#$(stemp0)$(stemp1)$(stemp2)$(stemp3)$(stemp4)$(stemp5)"
