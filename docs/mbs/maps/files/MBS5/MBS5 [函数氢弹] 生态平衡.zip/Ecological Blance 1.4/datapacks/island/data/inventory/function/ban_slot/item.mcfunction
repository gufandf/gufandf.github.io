
$clear @s *[custom_data~{tag:["ban_slot",$(slot)]}]
$execute if items entity @s container.$(slot) *[!custom_data~{tag:["ban_slot"]}] run summon item ~ ~ ~ {Item:{id:stone,count:1},Tags:[chosen]}
$execute if items entity @s container.$(slot) *[!custom_data~{tag:["ban_slot"]}] run item replace entity @n[type=item,tag=chosen] container.0 from entity @s container.$(slot)
tag @n[type=item,tag=chosen] remove chosen
$item replace entity @s container.$(slot) with stick[custom_data={tag:["ban_slot",$(slot)]},item_model=barrier,custom_name=[{translate:island.item.banslot.name}],lore=[[{translate:island.item.banslot.lore.0}]]]