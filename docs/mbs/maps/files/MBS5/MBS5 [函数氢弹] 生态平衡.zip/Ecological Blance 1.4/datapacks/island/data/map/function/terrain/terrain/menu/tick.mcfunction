
execute unless entity @s[tag=opened] run return fail

execute if score @s map.terrain.menu.page matches 1 unless items entity @s container.10 *[custom_data~{tag:["item.farmland"]}] run function map:terrain/terrain/menu/interact/buy_farmland
execute if score @s map.terrain.menu.page matches 1 unless items entity @s container.11 *[custom_data~{tag:["item.pigfarm"]}] run function map:terrain/terrain/menu/interact/buy_pigfarm
execute if score @s map.terrain.menu.page matches 1 unless items entity @s container.12 *[custom_data~{tag:["item.regrasser"]}] run function map:terrain/terrain/menu/interact/buy_regrasser
execute if score @s map.terrain.menu.page matches 1 unless items entity @s container.13 *[custom_data~{tag:["item.bruh"]}] run function map:terrain/terrain/menu/interact/buy_bruh
execute if score @s map.terrain.menu.page matches 1 unless items entity @s container.15 *[custom_data~{tag:["item.dirt"]}] run function map:terrain/terrain/menu/interact/buy_dirt
execute if score @s map.terrain.menu.page matches 1 unless items entity @s container.16 *[custom_data~{tag:["item.remove"]}] run function map:terrain/terrain/menu/interact/buy_remove

execute store result score item map.terrain.menu.item run data get entity @s Items
execute unless score @s map.terrain.menu.item = item map.terrain.menu.item run function map:terrain/terrain/menu/menu_item/menu_reset