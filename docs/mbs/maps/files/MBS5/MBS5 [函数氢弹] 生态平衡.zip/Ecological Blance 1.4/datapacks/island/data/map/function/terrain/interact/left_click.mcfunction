
execute if items entity @p[tag=chosen] weapon.* *[custom_data~{tag:[remove]}] run return run function map:terrain/interact/remove/0
