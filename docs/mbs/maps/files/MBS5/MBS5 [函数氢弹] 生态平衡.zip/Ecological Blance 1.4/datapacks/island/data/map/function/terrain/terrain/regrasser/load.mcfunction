
scoreboard objectives add map.terrain.regrasser dummy
 scoreboard players set #time map.terrain.regrasser 400