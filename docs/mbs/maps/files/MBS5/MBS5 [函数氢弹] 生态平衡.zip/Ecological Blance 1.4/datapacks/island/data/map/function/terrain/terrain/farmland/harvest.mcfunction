
execute unless score @s map.terrain_timer > #time map.terrain.farmland run playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
execute unless score @s map.terrain_timer > #time map.terrain.farmland run return run tellraw @p[tag=chosen] [{translate:island.tellraw.build.farmland.2}]

execute as @p[tag=chosen] run function map:terrain/terrain/farmland/harvest0
scoreboard players set @s map.terrain_timer 0
execute on passengers on passengers if entity @s[type=item_display] run data modify entity @s item.components."minecraft:item_model" set value "island:farmland0"
function map:terrain/terrain/bar/clear

playsound item.hoe.till record @a ~ ~ ~ 1 1
tellraw @p[tag=chosen] [{translate:island.tellraw.build.farmland.3}]
execute at @s run particle cloud ~ ~0.5 ~ 0.2 0.2 0.2 0.05 10 force @a
scoreboard players operation @s map.terrain_process += #change.farmland map.terrain_process