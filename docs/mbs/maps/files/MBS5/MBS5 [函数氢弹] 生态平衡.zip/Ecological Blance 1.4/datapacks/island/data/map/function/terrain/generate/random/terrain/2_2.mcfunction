
scoreboard players set #test map.generate.stat 1
execute if score #terrain map.generate.stat matches 6 run scoreboard players remove #amount.type map.generate.stat 1
execute if score #terrain map.generate.stat matches 6 as @e[type=interaction,scores={map.terrain=0},distance=3..,limit=1,sort=random] run function map:terrain/generate/random/terrain/2_2_0
execute unless score #terrain map.generate.stat matches 6 as @e[type=interaction,scores={map.terrain=0},distance=..1,limit=1,sort=random] run function map:terrain/generate/random/terrain/2_2_0
execute if score #test map.generate.stat matches 0 run return 0
execute if score #test map.generate.stat matches 1 run return 1