
title @s reset
title @s times 20 100 20

title @s title [{translate:island.title.day.0,with:[{score:{name:"#time.day",objective:map.game},color:yellow}]}]
tellraw @s [{translate:island.tellraw.day.0,with:[{score:{name:"#time.day",objective:map.game},color:yellow}]}]
playsound entity.player.levelup ambient @s ~ ~ ~ 1 1 0