
execute if score #time.day map.game matches 11.. if score #time map.game matches 5000.. unless score #storm0 map.disaster matches 1 if score #ebi0 ebi matches ..45 run function map:disaster/storm0/init
execute if score #time.day map.game matches 11.. if score #time map.game matches 12000.. unless score #storm0 map.disaster matches 1 if score #ebi0 ebi matches 0..100 run function map:game/ending/4/end
execute if score #ending map.game.ending matches 1.. run return fail
execute if score #ebi0 ebi matches ..-1 run function map:game/ending/1/init
execute if score #ebi0 ebi matches 50.. run function map:game/ending/2/init