
execute store result score #seed map.generate.stat run execute if items entity @p[tag=chosen] weapon *[custom_data~{tag:[seed]}]
execute if score #seed map.generate.stat matches 0 run playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
execute if score #seed map.generate.stat matches 0 run return run tellraw @p[tag=chosen] [{translate:island.tellraw.build.farmland.1}]

clear @p[tag=chosen] *[custom_data~{tag:["seed"]}] 1
scoreboard players set @s map.terrain_timer 1
execute on passengers on passengers if entity @s[type=item_display] run data modify entity @s item.components."minecraft:item_model" set value "island:farmland"

playsound item.hoe.till record @a ~ ~ ~ 1 1
tellraw @p[tag=chosen] [{translate:island.tellraw.build.farmland.4}]
