
tag @e[type=interaction,tag=terrain,scores={map.terrain=0..2}] add chosen
tag @e[type=interaction,tag=terrain,scores={map.structure=8}] add chosen
tag @e[type=interaction,tag=terrain,tag=chosen,scores={map.storm0=1..}] remove chosen
execute as @e[type=interaction,tag=terrain,tag=chosen,limit=1,sort=random] run scoreboard players set @s map.storm0 1
tag @e[tag=chosen] remove chosen