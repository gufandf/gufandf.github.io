
execute if entity @s[type=player] run return fail

execute if entity @s[type=interaction] run function interaction:tick1
function map:tick1