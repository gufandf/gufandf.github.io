
tellraw @s [{translate:island.tellraw.build.grass.0}]

function map:item/_get_item/resource/seed