
scoreboard objectives add inventory dummy
scoreboard objectives add inventory.slot_limit dummy