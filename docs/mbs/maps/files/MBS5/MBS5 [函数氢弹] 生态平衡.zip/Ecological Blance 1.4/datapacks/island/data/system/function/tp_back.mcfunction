
clear @s
team leave @s
stopsound @s
effect give @s resistance infinite 4 true
effect give @s regeneration infinite 0 true
effect give @s saturation infinite 0 true
execute as @s run tp @s -24 1 -17 90 0