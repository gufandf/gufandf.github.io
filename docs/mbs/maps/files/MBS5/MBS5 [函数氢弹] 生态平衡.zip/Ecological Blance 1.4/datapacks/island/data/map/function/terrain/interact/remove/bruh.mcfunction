
execute as @p[tag=chosen] run function map:terrain/interact/remove/bruh0
particle cloud ~ ~ ~ 0.2 0.2 0.2 0.05 5 force @a
playsound minecraft:block.bamboo.fall record @a ~ ~ ~ 2 1