
tellraw @s [{translate:island.tellraw.ending.0}]
tellraw @s [{translate:island.tellraw.ending2.0}]
tellraw @s [{translate:island.tellraw.ending2.1}]
tellraw @s [{translate:island.tellraw.ending2.2}]
tellraw @s [{translate:island.tellraw.ending2.3}]
tellraw @s [{translate:island.tellraw.ending.0}]