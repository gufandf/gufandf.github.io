execute as @s at @s run function map:terrain/terrain/menu/menu_item/detect
function map:terrain/terrain/menu/menu_item/target_player
clear @p[tag=target] *[custom_data~{tag:["clear","minecart"]}]
scoreboard players operation #price.wheat map.terrain.menu = #price.pigfarm.wheat map.terrain.menu
scoreboard players operation #price.wood map.terrain.menu = #price.pigfarm.wood map.terrain.menu
scoreboard players operation #price.seed map.terrain.menu = #price.pigfarm.seed map.terrain.menu
scoreboard players operation #price.porkchop map.terrain.menu = #price.pigfarm.porkchop map.terrain.menu
scoreboard players set #buy map.terrain.menu 0
execute as @p[tag=target] at @s run function map:terrain/terrain/menu/interact/resource
execute if score #buy map.terrain.menu matches 0 run return run tag @p[tag=target] remove target

execute as @p[tag=target] at @s run function map:terrain/terrain/menu/interact/buy_pigfarm0