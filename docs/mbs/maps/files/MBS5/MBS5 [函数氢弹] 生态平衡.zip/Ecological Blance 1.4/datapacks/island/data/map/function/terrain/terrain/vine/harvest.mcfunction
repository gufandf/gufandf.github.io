
playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
tellraw @p[tag=chosen] [{translate:island.tellraw.build.vine.1}]
