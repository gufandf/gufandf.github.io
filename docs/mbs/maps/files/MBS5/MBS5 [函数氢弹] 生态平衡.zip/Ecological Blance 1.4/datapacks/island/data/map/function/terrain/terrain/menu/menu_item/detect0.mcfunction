
summon item ~ ~1 ~ {Item:{id:stone,count:1},Tags:[chosen]}
$item replace entity @n[type=item,tag=chosen] container.0 from entity @s container.$(slot)
$item replace entity @s container.$(slot) with air
tag @n[type=item,tag=chosen] remove chosen