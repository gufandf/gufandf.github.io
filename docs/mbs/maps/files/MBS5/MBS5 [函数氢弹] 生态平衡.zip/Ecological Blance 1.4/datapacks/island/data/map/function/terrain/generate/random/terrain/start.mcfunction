
scoreboard players operation #size map.generate.stat = #size map.generate.weight
execute positioned 16 3 16 run function map:terrain/generate/random/terrain/0