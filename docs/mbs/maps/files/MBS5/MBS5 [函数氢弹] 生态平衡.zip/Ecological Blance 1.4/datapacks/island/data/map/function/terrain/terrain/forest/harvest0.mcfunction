#3..7
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
function map:item/_get_item/resource/wood
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wood0 map.terrain.forest run function map:item/_get_item/resource/wood
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wood0 map.terrain.forest run function map:item/_get_item/resource/wood
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wood0 map.terrain.forest run function map:item/_get_item/resource/wood
execute store result score random map.generate.stat run random value 1..100
execute if score random map.generate.stat <= #chance.wood0 map.terrain.forest run function map:item/_get_item/resource/wood