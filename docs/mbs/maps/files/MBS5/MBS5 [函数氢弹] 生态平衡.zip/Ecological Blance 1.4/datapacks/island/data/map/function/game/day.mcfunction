
execute if entity @s[gamemode=!adventure] run return run function map:game/day0
execute store result score #wheat map.game run execute if items entity @s container.* *[custom_data~{tag:[wheat]}]
execute store result score #seed map.game run execute if items entity @s container.* *[custom_data~{tag:[seed]}]
execute store result score #wood map.game run execute if items entity @s container.* *[custom_data~{tag:[wood]}]
execute store result score #porkchop map.game run execute if items entity @s container.* *[custom_data~{tag:[porkchop]}]
execute if score #wheat map.game matches 5.. run function map:game/day0
execute if score #wheat map.game matches 5.. run tellraw @s [{translate:island.tellraw.eat.0}]
execute if score #wheat map.game matches 5.. run return run clear @s *[custom_data~{tag:[wheat]}] 5
execute if score #porkchop map.game matches 3.. run function map:game/day0
execute if score #porkchop map.game matches 3.. run tellraw @s [{translate:island.tellraw.eat.1}]
execute if score #porkchop map.game matches 3.. run return run clear @s *[custom_data~{tag:[porkchop]}] 3
function map:game/ending/5/end