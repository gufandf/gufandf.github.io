
execute if entity @s[advancements={map:minecart_open=true}] run function map:terrain/terrain/menu/open