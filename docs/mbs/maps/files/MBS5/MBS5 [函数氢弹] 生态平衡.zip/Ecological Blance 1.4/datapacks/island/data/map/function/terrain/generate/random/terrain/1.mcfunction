
#每个格子刷个marker
scoreboard players operation #loop map.generate.stat = #size map.generate.weight
scoreboard players operation #loop map.generate.stat += #size map.generate.weight
scoreboard players operation #loop map.generate.stat += #1 number
scoreboard players set #i map.generate.stat 0
scoreboard players set #i0 map.generate.stat 0
function map:terrain/generate/random/terrain/1_0
function map:terrain/generate/random/terrain/2