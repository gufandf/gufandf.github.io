

execute if score #tick map.game matches 1 run function map:game/tick
execute if score #tick map.game matches 1 run function map:disaster/tick
execute if score #tick map.game matches 1 run function map:terrain/ebi/tick
function map:terrain/generate/tick