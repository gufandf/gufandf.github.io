
summon interaction ~ ~ ~ {Tags:[chosen2,interaction,precedence],height:4.5,width:4.5}
scoreboard players operation @n[type=interaction,tag=interaction,tag=chosen2] uuid = @s uuid
tag @n[type=interaction,tag=chosen2] remove chosen2
