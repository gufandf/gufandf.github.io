
give @s iron_nugget[\
    item_model=wheat_seeds,\
    custom_data={\
            tag:[item,resource,seed]\
        },\
    custom_name=[{translate:island.item.resource.seed.name}],\
    lore=[\
        [{translate:island.item.resource.seed.lore.0}],\
        [{translate:island.item.resource.seed.lore.1}]\
    ],\
    unbreakable={},\
    tooltip_display={hidden_components:[unbreakable]}\
]