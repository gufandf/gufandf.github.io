
tellraw @s [{translate:island.tellraw.ending.0}]
tellraw @s [{translate:island.tellraw.ending4.0}]
tellraw @s [{translate:island.tellraw.ending4.1}]
tellraw @s [{translate:island.tellraw.ending4.2}]
tellraw @s [{translate:island.tellraw.ending4.3}]
tellraw @s [{translate:island.tellraw.ending.0}]