
tellraw @s [{translate:island.tellraw.build.regrasser.1}]

