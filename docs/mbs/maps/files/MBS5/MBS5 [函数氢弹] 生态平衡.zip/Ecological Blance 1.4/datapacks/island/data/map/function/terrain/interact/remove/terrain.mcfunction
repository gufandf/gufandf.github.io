
execute if score @s map.structure matches 1 run return fail

execute if score @s map.terrain matches 2 run scoreboard players set @s map.terrain 1
execute if score @s map.terrain matches 0 run scoreboard players set @s map.terrain 2