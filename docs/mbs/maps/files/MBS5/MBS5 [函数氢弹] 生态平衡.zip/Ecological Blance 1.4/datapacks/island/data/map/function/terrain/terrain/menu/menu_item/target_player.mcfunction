
scoreboard players operation uuid map.terrain.menu.uuid = @s map.terrain.menu.uuid
execute as @a if score @s uuid = uuid map.terrain.menu.uuid run tag @s add target
