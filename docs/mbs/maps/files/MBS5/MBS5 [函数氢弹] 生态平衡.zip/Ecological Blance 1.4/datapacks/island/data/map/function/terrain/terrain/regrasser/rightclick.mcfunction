
function map:terrain/terrain/vine/harvest