
execute if entity @s[advancements={inventory:inventory_changed=true}] at @s run function inventory:inventory_changed

execute unless score @s inventory.slot_limit0 = @s inventory.slot_limit at @s run function inventory:ban_slot/detect
execute store result score @s inventory.slot_limit0 run execute if items entity @s container.* *[custom_data~{tag:["ban_slot"]}]
