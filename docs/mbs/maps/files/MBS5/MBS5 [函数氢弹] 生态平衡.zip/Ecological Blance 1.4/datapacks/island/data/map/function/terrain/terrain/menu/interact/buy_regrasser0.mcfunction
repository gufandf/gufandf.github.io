
clear @s *[custom_data~{tag:[wood]}] 5
clear @s *[custom_data~{tag:[porkchop]}] 4
clear @s *[custom_data~{tag:[wheat]}] 6
 function map:item/_get_item/build/regrasser
tag @s remove target