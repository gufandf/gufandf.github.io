
execute if entity @s[tag=display] run function map:item/tick1
execute store result score #vine map.terrain run execute if entity @e[type=interaction,scores={map.vine=1}]
scoreboard players operation #vine map.terrain /= #2 number
execute if entity @s[type=interaction,tag=terrain,tag=!ride] run function map:terrain/tick1
execute if entity @s[type=chest_minecart,tag=terrain,tag=menu] run function map:terrain/terrain/menu/tick