
function map:terrain/ebi/calculate/start
execute unless score #ebi0 ebi = #ebi0 ebi run scoreboard players operation #ebi0 ebi = #ebi ebi
function map:terrain/ebi/actionbar
execute if score #ebi0 ebi = #ebi ebi run return fail
scoreboard players operation #ebi1 ebi = #ebi0 ebi
scoreboard players operation #ebi1 ebi -= #ebi ebi
execute if score #ebi1 ebi matches -10..10 run scoreboard players operation #speed ebi = #speed0 ebi
execute unless score #ebi1 ebi matches -10..10 if score #ebi1 ebi matches -20..20 run scoreboard players operation #speed ebi = #speed1 ebi
execute unless score #ebi1 ebi matches -20..20 if score #ebi1 ebi matches -30..30 run scoreboard players operation #speed ebi = #speed2 ebi
execute unless score #ebi1 ebi matches -30..30 run scoreboard players operation #speed ebi = #speed3 ebi
scoreboard players add #speed_0 ebi 1
execute if score #speed_0 ebi < #speed ebi run return fail
scoreboard players set #speed_0 ebi 0
execute if score #ebi0 ebi < #ebi ebi run scoreboard players add #ebi0 ebi 1
execute if score #ebi0 ebi > #ebi ebi run scoreboard players remove #ebi0 ebi 1