
give @s iron_nugget[\
    item_model=wheat,\
    custom_data={\
            tag:[item,resource,wheat]\
        },\
    custom_name=[{translate:island.item.resource.wheat.name}],\
    lore=[\
        [{translate:island.item.resource.wheat.lore.0}],\
        [{translate:island.item.resource.wheat.lore.1}]\
    ],\
    unbreakable={},\
    tooltip_display={hidden_components:[unbreakable]}\
]