
execute if score #ebi ebi matches 60.. if score #storm.ebi map.disaster matches 0 run function map:disaster/storm/init
execute if score #ebi ebi matches 90.. if score #storm.ebi map.disaster matches 1 run function map:disaster/storm/init
execute if score #time.day map.game matches 5 if score #time map.game matches 8000 run function map:disaster/storm/init
execute if score #time.day map.game matches 8 if score #time map.game matches 12000 run function map:disaster/storm/init
execute if score #time.day map.game matches 9 if score #time map.game matches 12000 run function map:disaster/storm/init
execute if score #time.day map.game matches 10 if score #time map.game matches 12000 run function map:disaster/storm/init