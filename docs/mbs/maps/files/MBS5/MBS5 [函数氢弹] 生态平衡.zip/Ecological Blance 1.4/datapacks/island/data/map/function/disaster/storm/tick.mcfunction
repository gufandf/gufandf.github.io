
scoreboard players add @e[scores={map.structure=4,map.terrain_timer=1..200}] map.terrain_timer 1
scoreboard players add @e[scores={map.structure=2,map.terrain_timer=1..200}] map.terrain_timer 1
execute positioned 16 8 16 run particle campfire_cosy_smoke ~ ~ ~ 1 0 1 0 5 force @a
scoreboard players add #storm.timer map.disaster 1
execute if score #storm.timer map.disaster matches 40 run weather thunder
execute if score #storm.timer map.disaster matches 40.. positioned 16 8 16 run particle rain ~ ~ ~ 1 0 1 0 5 force @a
execute if score #storm.timer map.disaster matches 60 run function map:disaster/storm/chose
execute if score #storm.timer map.disaster matches 90 run function map:disaster/storm/chose
execute if score #storm.timer map.disaster matches 120 run function map:disaster/storm/chose
execute as @e[type=interaction,tag=terrain,scores={map.storm=1..}] at @s run function map:disaster/storm/tick0
execute if score #storm.timer map.disaster <= #storm.time map.disaster run return fail

function map:disaster/storm/end