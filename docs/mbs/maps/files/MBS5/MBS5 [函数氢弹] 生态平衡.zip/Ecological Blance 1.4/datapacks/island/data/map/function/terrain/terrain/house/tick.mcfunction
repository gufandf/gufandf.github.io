
execute at @s unless entity @e[type=chest_minecart,tag=terrain,tag=minecart,distance=..0.75] run function map:terrain/terrain/menu/0