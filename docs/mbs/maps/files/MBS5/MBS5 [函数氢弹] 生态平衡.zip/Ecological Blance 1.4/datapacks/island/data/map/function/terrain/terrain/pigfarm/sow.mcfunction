
execute store result score #wheat map.generate.stat run execute if items entity @p[tag=chosen] weapon *[custom_data~{tag:[wheat]}]
execute if score #wheat map.generate.stat < #wheat map.terrain.pigfarm run playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
execute if score #wheat map.generate.stat < #wheat map.terrain.pigfarm run return run tellraw @p[tag=chosen] [{translate:island.tellraw.build.pigfarm.1,with:[{score:{name:"#wheat",objective:"map.generate.stat"}},{score:{name:"#wheat",objective:"map.terrain.pigfarm"}}]}]

clear @p[tag=chosen] *[custom_data~{tag:["wheat"]}] 2
scoreboard players set @s map.terrain_timer 1
execute on passengers on passengers if entity @s[type=item_display] run data modify entity @s item.components."minecraft:item_model" set value "island:pigfarm"

playsound entity.pig.hurt record @a ~ ~ ~ 1 1
tellraw @p[tag=chosen] [{translate:island.tellraw.build.pigfarm.4}]
