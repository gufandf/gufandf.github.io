
#0:空气 1:草 2:树 3:房子
scoreboard players operation @s map.vine0 = @s map.vine
function map:terrain/terrain/bar/clear
execute on passengers on passengers if entity @s[tag=vine] run kill @s
execute unless score @s map.terrain matches 0..2 run return run scoreboard players set @s map.vine 0
execute if score @s map.terrain matches 0..2 if score @s map.vine matches 1 run function map:terrain/display/vine/0

