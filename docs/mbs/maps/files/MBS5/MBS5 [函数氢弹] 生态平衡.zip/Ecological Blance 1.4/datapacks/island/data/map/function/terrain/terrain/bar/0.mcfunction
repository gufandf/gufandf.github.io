
execute on passengers on passengers on passengers if entity @s[type=armor_stand] run return run function map:terrain/terrain/bar/1
summon interaction ~ ~ ~ {Tags:[terrain,text,ride,chosen],width:0,height:0.75,Passengers:[\
{id:armor_stand,Tags:[terrain,text,ride,chosen],Invisible:1b,Marker:1b,CustomNameVisible:1b,CustomName:[{text:""}]}]}
execute on passengers if entity @s[tag=position_fix] run ride @n[type=interaction,tag=text,tag=chosen] mount @s
tag @e[tag=chosen] remove chosen
execute on passengers on passengers on passengers if entity @s[type=armor_stand] run return run function map:terrain/terrain/bar/1
