
particle campfire_signal_smoke ~ ~4 ~ 0.1 0 0.1 0 1 force @a
particle wax_off ~ ~ ~ 0.2 0.2 0.2 0.05 1 force @a
scoreboard players add @s map.storm 1
execute if score @s map.storm matches 40.. run function map:disaster/storm/strike