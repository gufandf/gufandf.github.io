
scoreboard players set #storm0 map.disaster 0
scoreboard players set #storm.timer map.disaster 0
weather clear