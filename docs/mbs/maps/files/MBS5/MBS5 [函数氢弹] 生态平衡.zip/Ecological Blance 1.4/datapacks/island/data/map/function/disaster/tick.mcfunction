
execute unless score #end map.game.ending matches 1.. run function map:disaster/detect
execute if score #storm map.disaster matches 1 run function map:disaster/storm/tick
execute if score #storm0 map.disaster matches 1 run function map:disaster/storm0/tick