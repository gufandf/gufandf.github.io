
function map:terrain/generate/load
function map:terrain/terrain/load
function map:terrain/ebi/load
 
#0:草地 1:石头 2:沙子 3:水 4:海水 5:淡水 6:替换海水
scoreboard objectives add map.terrain dummy
 scoreboard players set #max.bruh map.terrain 6
scoreboard objectives add map.terrain0 dummy
scoreboard objectives add map.structure dummy
scoreboard objectives add map.structure0 dummy
scoreboard objectives add map.terrain.x dummy
scoreboard objectives add map.terrain.y dummy
scoreboard objectives add map.vine dummy
scoreboard objectives add map.vine0 dummy

scoreboard objectives add map.terrain_timer dummy
scoreboard objectives add map.terrain_timer0 dummy

scoreboard objectives add map.terrain_process dummy
 scoreboard players set #change map.terrain_process 100
 scoreboard players set #change.forest map.terrain_process 7
 scoreboard players set #change.farmland map.terrain_process 7
 scoreboard players set #change.pigfarm map.terrain_process 7
 