
clear @s *[custom_data~{tag:["ban_slot",offhand]}]
execute if items entity @s weapon.offhand *[!custom_data~{tag:["ban_slot"]}] run summon item ~ ~ ~ {Item:{id:stone,count:1},Tags:[chosen]}
execute if items entity @s weapon.offhand *[!custom_data~{tag:["ban_slot"]}] run item replace entity @n[type=item,tag=chosen] container.0 from entity @s weapon.offhand
tag @n[type=item,tag=chosen] remove chosen
item replace entity @s weapon.offhand with air