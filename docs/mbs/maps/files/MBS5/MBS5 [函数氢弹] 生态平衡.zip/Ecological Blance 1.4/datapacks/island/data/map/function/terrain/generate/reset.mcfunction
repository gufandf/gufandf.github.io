
scoreboard objectives remove map.generate
scoreboard objectives remove map.generate.weight