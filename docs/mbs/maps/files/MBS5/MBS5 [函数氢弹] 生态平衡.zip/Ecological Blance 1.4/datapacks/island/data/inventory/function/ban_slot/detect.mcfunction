
function inventory:ban_slot/operation
execute unless score @s inventory.slot_limit matches 0.. run return run scoreboard players operation @s inventory.slot_limit = limit inventory.slot_limit

execute if score @s inventory.slot_limit0 > @s inventory.slot_limit run clear @s *[custom_data~{tag:["ban_slot"]}]
execute if entity @s[gamemode=adventure] run data modify entity @n[type=item] PickupDelay set value 0
execute if entity @s[gamemode=adventure] run data modify entity @n[type=item] Owner set from entity @s UUID
kill @e[type=item,nbt={Item:{components:{"minecraft:custom_data":{tag:["ban_slot"]}}}}]
execute if items entity @s player.cursor *[custom_data~{tag:["ban_slot"]}] run item replace entity @s player.cursor with air
execute if items entity @s player.crafting.0 *[custom_data~{tag:["ban_slot"]}] run item replace entity @s player.crafting.0 with air
execute if items entity @s player.crafting.1 *[custom_data~{tag:["ban_slot"]}] run item replace entity @s player.crafting.1 with air
execute if items entity @s player.crafting.2 *[custom_data~{tag:["ban_slot"]}] run item replace entity @s player.crafting.2 with air
execute if items entity @s player.crafting.3 *[custom_data~{tag:["ban_slot"]}] run item replace entity @s player.crafting.3 with air
execute if score @s inventory.slot_limit matches 1.. unless items entity @s container.9 *[custom_data~{tag:["ban_slot","9"]}] run function inventory:ban_slot/item {slot:9}
execute if score @s inventory.slot_limit matches 2.. unless items entity @s container.10 *[custom_data~{tag:["ban_slot","10"]}] run function inventory:ban_slot/item {slot:10}
execute if score @s inventory.slot_limit matches 3.. unless items entity @s container.11 *[custom_data~{tag:["ban_slot","11"]}] run function inventory:ban_slot/item {slot:11}
execute if score @s inventory.slot_limit matches 4.. unless items entity @s container.12 *[custom_data~{tag:["ban_slot","12"]}] run function inventory:ban_slot/item {slot:12}
execute if score @s inventory.slot_limit matches 5.. unless items entity @s container.13 *[custom_data~{tag:["ban_slot","13"]}] run function inventory:ban_slot/item {slot:13}
execute if score @s inventory.slot_limit matches 6.. unless items entity @s container.14 *[custom_data~{tag:["ban_slot","14"]}] run function inventory:ban_slot/item {slot:14}
execute if score @s inventory.slot_limit matches 7.. unless items entity @s container.15 *[custom_data~{tag:["ban_slot","15"]}] run function inventory:ban_slot/item {slot:15}
execute if score @s inventory.slot_limit matches 8.. unless items entity @s container.16 *[custom_data~{tag:["ban_slot","16"]}] run function inventory:ban_slot/item {slot:16}
execute if score @s inventory.slot_limit matches 9.. unless items entity @s container.17 *[custom_data~{tag:["ban_slot","17"]}] run function inventory:ban_slot/item {slot:17}
execute if score @s inventory.slot_limit matches 10.. unless items entity @s container.18 *[custom_data~{tag:["ban_slot","18"]}] run function inventory:ban_slot/item {slot:18}
execute if score @s inventory.slot_limit matches 11.. unless items entity @s container.19 *[custom_data~{tag:["ban_slot","19"]}] run function inventory:ban_slot/item {slot:19}
execute if score @s inventory.slot_limit matches 12.. unless items entity @s container.20 *[custom_data~{tag:["ban_slot","20"]}] run function inventory:ban_slot/item {slot:20}
execute if score @s inventory.slot_limit matches 13.. unless items entity @s container.21 *[custom_data~{tag:["ban_slot","21"]}] run function inventory:ban_slot/item {slot:21}
execute if score @s inventory.slot_limit matches 14.. unless items entity @s container.22 *[custom_data~{tag:["ban_slot","22"]}] run function inventory:ban_slot/item {slot:22}
execute if score @s inventory.slot_limit matches 15.. unless items entity @s container.23 *[custom_data~{tag:["ban_slot","23"]}] run function inventory:ban_slot/item {slot:23}
execute if score @s inventory.slot_limit matches 16.. unless items entity @s container.24 *[custom_data~{tag:["ban_slot","24"]}] run function inventory:ban_slot/item {slot:24}
execute if score @s inventory.slot_limit matches 17.. unless items entity @s container.25 *[custom_data~{tag:["ban_slot","25"]}] run function inventory:ban_slot/item {slot:25}
execute if score @s inventory.slot_limit matches 18.. unless items entity @s container.26 *[custom_data~{tag:["ban_slot","26"]}] run function inventory:ban_slot/item {slot:26}
execute if score @s inventory.slot_limit matches 19.. unless items entity @s container.27 *[custom_data~{tag:["ban_slot","27"]}] run function inventory:ban_slot/item {slot:27}
execute if score @s inventory.slot_limit matches 20.. unless items entity @s container.28 *[custom_data~{tag:["ban_slot","28"]}] run function inventory:ban_slot/item {slot:28}
execute if score @s inventory.slot_limit matches 21.. unless items entity @s container.29 *[custom_data~{tag:["ban_slot","29"]}] run function inventory:ban_slot/item {slot:29}
execute if score @s inventory.slot_limit matches 22.. unless items entity @s container.30 *[custom_data~{tag:["ban_slot","30"]}] run function inventory:ban_slot/item {slot:30}
execute if score @s inventory.slot_limit matches 23.. unless items entity @s container.31 *[custom_data~{tag:["ban_slot","31"]}] run function inventory:ban_slot/item {slot:31}
execute if score @s inventory.slot_limit matches 24.. unless items entity @s container.32 *[custom_data~{tag:["ban_slot","32"]}] run function inventory:ban_slot/item {slot:32}
execute if score @s inventory.slot_limit matches 25.. unless items entity @s container.33 *[custom_data~{tag:["ban_slot","33"]}] run function inventory:ban_slot/item {slot:33}
execute if score @s inventory.slot_limit matches 26.. unless items entity @s container.34 *[custom_data~{tag:["ban_slot","34"]}] run function inventory:ban_slot/item {slot:34}
execute if score @s inventory.slot_limit matches 27.. unless items entity @s container.35 *[custom_data~{tag:["ban_slot","35"]}] run function inventory:ban_slot/item {slot:35}
execute if score @s inventory.slot_limit matches 28.. unless items entity @s container.8 *[custom_data~{tag:["ban_slot","8"]}] run function inventory:ban_slot/item {slot:8}
execute if score @s inventory.slot_limit matches 29.. unless items entity @s container.7 *[custom_data~{tag:["ban_slot","7"]}] run function inventory:ban_slot/item {slot:7}
execute if score @s inventory.slot_limit matches 30.. unless items entity @s container.6 *[custom_data~{tag:["ban_slot","6"]}] run function inventory:ban_slot/item {slot:6}
execute if score @s inventory.slot_limit matches 31.. unless items entity @s container.5 *[custom_data~{tag:["ban_slot","5"]}] run function inventory:ban_slot/item {slot:5}
execute if score @s inventory.slot_limit matches 32.. unless items entity @s container.4 *[custom_data~{tag:["ban_slot","4"]}] run function inventory:ban_slot/item {slot:4}
execute if score @s inventory.slot_limit matches 33.. unless items entity @s container.3 *[custom_data~{tag:["ban_slot","3"]}] run function inventory:ban_slot/item {slot:3}
execute if score @s inventory.slot_limit matches 34.. unless items entity @s container.2 *[custom_data~{tag:["ban_slot","2"]}] run function inventory:ban_slot/item {slot:2}
execute if score @s inventory.slot_limit matches 35.. unless items entity @s container.1 *[custom_data~{tag:["ban_slot","1"]}] run function inventory:ban_slot/item {slot:1}
function inventory:ban_slot/item0


scoreboard players operation @s inventory.slot_limit = limit inventory.slot_limit