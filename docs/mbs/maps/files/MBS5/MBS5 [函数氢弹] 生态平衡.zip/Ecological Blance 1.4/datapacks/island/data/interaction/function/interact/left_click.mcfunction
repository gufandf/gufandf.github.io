
scoreboard players set @s interaction.left_click 1
function interaction:interact/click
tag @s remove chosen