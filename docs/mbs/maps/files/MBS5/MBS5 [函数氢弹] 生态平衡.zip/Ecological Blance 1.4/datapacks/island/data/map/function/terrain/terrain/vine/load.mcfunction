
scoreboard objectives add map.terrain.vine dummy
 scoreboard players set #time map.terrain.vine 750