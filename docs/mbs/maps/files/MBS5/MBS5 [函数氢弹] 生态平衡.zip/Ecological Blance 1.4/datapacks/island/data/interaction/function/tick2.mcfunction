
execute if entity @s[nbt={HurtTime:10s}] run function interaction:detect/left_click0