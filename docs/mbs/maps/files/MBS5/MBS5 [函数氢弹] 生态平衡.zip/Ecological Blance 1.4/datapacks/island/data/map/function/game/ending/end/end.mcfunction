
function _:init
title @a reset
title @a times 0 2000 0
title @a title [{text:""}]