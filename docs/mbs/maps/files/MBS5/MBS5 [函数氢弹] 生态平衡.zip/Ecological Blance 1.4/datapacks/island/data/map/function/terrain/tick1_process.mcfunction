
#0:空气 1:草 2:树 3:房子
scoreboard players operation @s map.terrain_process -= #change map.terrain_process
function map:terrain/terrain/bar/clear
execute on passengers on passengers run kill @s
execute on passengers run kill @s
execute if score @s map.structure matches 2 run scoreboard players set @s map.structure 1
execute if score @s map.structure matches 4 run scoreboard players set @s map.terrain 2
execute if score @s map.structure matches 4 run scoreboard players set @s map.structure 0
execute if score @s map.structure matches 5 run scoreboard players set @s map.terrain 2
execute if score @s map.structure matches 5 run scoreboard players set @s map.structure 0
