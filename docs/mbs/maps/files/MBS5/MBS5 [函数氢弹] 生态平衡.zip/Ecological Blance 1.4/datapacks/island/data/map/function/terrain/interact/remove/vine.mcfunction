
execute as @p[tag=chosen] run function map:terrain/interact/remove/vine0

particle cloud ~ ~ ~ 0.2 0.2 0.2 0.05 5 force @a
playsound block.grass.break record @a ~ ~ ~ 2 0.25
playsound block.grass.break record @a ~ ~ ~ 2 0.25
playsound block.grass.break record @a ~ ~ ~ 2 0.25
scoreboard players set @s map.vine 0