
execute at @s run particle happy_villager ~ ~0.5 ~ 0.2 0.2 0.2 0.05 10 force @a
execute if score @s map.vine matches 0 run return run scoreboard players set @s map.vine 1
execute if score @s map.terrain matches 2 run return run scoreboard players set @s map.terrain 0
execute if score @s map.terrain matches 1 run return run scoreboard players set @s map.terrain 2