
playsound entity.enderman.teleport ambient @p[tag=chosen] ~ ~ ~ 1 0 0
return run tellraw @p[tag=chosen] [{translate:island.tellraw.build.regrasser.1}]
