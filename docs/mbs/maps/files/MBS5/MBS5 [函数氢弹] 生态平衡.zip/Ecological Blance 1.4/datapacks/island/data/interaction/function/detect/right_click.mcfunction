tag @s add target
scoreboard players set @s interaction.right_click 1
execute store result score #player_uuid0 uuid0 run data get entity @s interaction.player[0]
execute store result score #player_uuid1 uuid1 run data get entity @s interaction.player[1]
execute store result score #player_uuid2 uuid2 run data get entity @s interaction.player[2]
execute store result score #player_uuid3 uuid3 run data get entity @s interaction.player[3]
data remove entity @s interaction

execute as @a if score @s uuid0 = #player_uuid0 uuid0 if score @s uuid1 = #player_uuid1 uuid1 if score @s uuid2 = #player_uuid2 uuid2 if score @s uuid3 = #player_uuid3 uuid3 run tag @s add chosen

execute if entity @s[tag=interactable] run function interaction:loop/hit
execute if entity @s[tag=interactable] run return run tag @s remove target
execute as @p[tag=chosen] at @s run function interaction:interact/right_click
tag @s remove target

