
advancement revoke @s only map:minecart_open
scoreboard players operation uuid map.terrain.menu.uuid = @s uuid
playsound block.wooden_door.open ambient @s ~ ~ ~ 1 1 0
tag @s add chosen
execute as @e[type=chest_minecart,tag=terrain,tag=minecart,tag=opened] at @s if score @s map.terrain.menu.uuid = uuid map.terrain.menu.uuid run function system:death
execute as @e[type=chest_minecart,tag=terrain,tag=minecart,tag=!opened,nbt=!{LootTable:"map:nothing"}] at @s run function map:terrain/terrain/menu/open1
tag @s remove chosen
