#去除流中的重复元素，仅当流为对象流时可用

#scoreboard players set index stream 0
#execute store result score length stream run function patrickstool:stream/count

#清空缓存流
data modify storage patrickstool:stream/constant_stream {} merge value {value:[]}

#data modify storage patrickstool:stream/operated {} merge value {}
#function patrickstool:stream/private/distinct/distinctstep

$function patrickstool:stream/foreach {function:"patrickstool:stream/private/distinct/distinctstep",address:"$(address)"}
$data modify $(address) set from storage patrickstool:stream/constant_stream value