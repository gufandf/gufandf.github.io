#foreach的中间步骤。需要一个function字符串指定要执行的函数
#在使用此函数时，被传参的函数实际上也可以直接使用$(length)访问当前的流长度

#提取数据
$scoreboard players set index stream $(index)
$scoreboard players set length stream $(length)
#判断运行结束
execute if score index stream >= length stream run return fail
#提取元素
#   重置record（这条命令无用）
#data modify storage patrickstool:stream/record {} set value {}
#   用下标访问流并提取元素
$data modify storage patrickstool:stream/record address set value "$(address)"
$data modify storage patrickstool:stream/record index set value $(index)
function patrickstool:stream/private/get_from_index with storage patrickstool:stream/record
#已弃用：现在我们直接使用record而非operated   将下标一并打包
#execute store result storage patrickstool:stream/operated index int 1 run scoreboard players get index stream

#进行操作
$function $(function) with storage patrickstool:stream/record

#下标重置
$scoreboard players set index stream $(index)
$scoreboard players set length stream $(length)
#下标加一
scoreboard players add index stream 1
#打包
$data modify storage patrickstool:stream/record length set value $(length)
$data modify storage patrickstool:stream/record function set value "$(function)"
$data modify storage patrickstool:stream/record address set value "$(address)"
execute store result storage patrickstool:stream/record index int 1 run scoreboard players get index stream


#断点
#$say $(index)

#下一次循环
function patrickstool:stream/private/foreach/foreachstep with storage patrickstool:stream/record
