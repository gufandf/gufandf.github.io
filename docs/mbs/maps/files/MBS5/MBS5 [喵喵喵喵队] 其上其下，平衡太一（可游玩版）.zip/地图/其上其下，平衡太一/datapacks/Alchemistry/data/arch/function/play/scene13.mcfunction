
execute as @a if score @s play_main matches 23 run tellraw @s [{text:"<Elias> 又做了不少委托"}]
execute as @a if score @s play_main matches 24 run tellraw @s [{text:"<Elias> 去看看大家怎么样了吧"}]
execute as @a if score @s play_main matches 24 run title @s title [{text:"其上其下，平衡太一"}]
execute as @a if score @s play_main matches 24 run title @s subtitle [{text:"第三章：死亡"}]
execute as @a if score @s play_main matches 24 run scoreboard players set @s play1 22

execute as @a if score @s play_main matches 24 run scoreboard players set @s play2 22

execute as @a if score @s play_main matches 24 run scoreboard players set @s play4 22
execute as @a if score @s play_main matches 23..24 run scoreboard players add @s play_main 1
