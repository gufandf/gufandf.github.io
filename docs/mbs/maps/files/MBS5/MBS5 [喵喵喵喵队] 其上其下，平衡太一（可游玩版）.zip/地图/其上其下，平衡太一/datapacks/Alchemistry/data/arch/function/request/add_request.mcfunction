#添加新的委托

#判断当前委托数量是否已经达到5个
scoreboard players set result runtime 0
execute store result score result runtime run data get storage arch:content_requests values
execute if score result runtime matches 5.. run return fail

#过滤不符合要求的
data remove storage arch:content_requests record
data modify storage arch:content_requests record set from storage arch:requests values
function patrickstool:stream/batch {address:"storage arch:content_requests record",command:["filter"],argus:["arch:shop/exp_filter"]}

#随机一个数字
execute store result score random runtime run random value 0..1000000
#取余数
execute store result score result runtime run data get storage arch:content_requests record
scoreboard players operation random runtime %= result runtime
#抽一个
execute store result storage arch:record index int 1 run scoreboard players get random runtime
function arch:steps/add_request with storage arch:record