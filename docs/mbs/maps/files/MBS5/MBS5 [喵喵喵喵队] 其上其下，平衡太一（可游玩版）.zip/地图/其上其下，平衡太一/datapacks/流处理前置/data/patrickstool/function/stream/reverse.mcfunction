#颠倒输入的流

data modify storage patrickstool:stream/constant_stream {} merge value {value:[]}

$function patrickstool:stream/foreach {address:"$(address)",function:"patrickstool:stream/private/reverse/step"}
$data modify $(address) set from storage patrickstool:stream/constant_stream value