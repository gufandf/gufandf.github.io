#由于先前设置的时候下标是+1过的，这里减回来
scoreboard players remove @s shop 1
execute store result storage arch:record index int 1 run scoreboard players get @s shop
#用下标访问
function arch:steps/buy with storage arch:record