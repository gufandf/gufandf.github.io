#对流中的每一个元素都应用一次指定的函数。

#data modify storage patrickstool:stream/record {} set value {}
#scoreboard players set index stream 0

#记录流的长度
$execute store result storage patrickstool:stream/record length int 1 run function patrickstool:stream/count {address:"$(address)"}
#传入下标为0
data modify storage patrickstool:stream/record index set value 0
#传入要执行的函数和地址
$data modify storage patrickstool:stream/record function set value "$(function)"
$data modify storage patrickstool:stream/record address set value "$(address)"
#迭代开始
function patrickstool:stream/private/foreach/foreachstep with storage patrickstool:stream/record