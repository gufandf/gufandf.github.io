
execute as @a if score @s play4 matches 11 run tellraw @s [{text:"<Percival> 今天天气不错啊，Elias"}]
execute as @a if score @s play4 matches 12 run tellraw @s [{text:"<Elias> 是这样，Percival老板"}]
execute as @a if score @s play4 matches 13 run tellraw @s [{text:"<Percival> 我这里进了新的货物，有很多金属，你需要的话可以低价卖给你"}]
execute as @a if score @s play4 matches 14 run tellraw @s [{text:"<Elias> 帮大忙了。"}]
execute as @a if score @s play4 matches 11..14 run scoreboard players add @s play4 1
