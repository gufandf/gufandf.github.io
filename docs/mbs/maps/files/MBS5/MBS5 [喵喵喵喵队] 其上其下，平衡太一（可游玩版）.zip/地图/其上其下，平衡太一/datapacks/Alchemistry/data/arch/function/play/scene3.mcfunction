
execute as @a if score @s play_main matches 11 run tellraw @s [{text:"<???> 卖花喽————，咳咳，新鲜的花————"}]
execute as @a if score @s play_main matches 12 run tellraw @s [{text:"<Elias> 左边好像有人在叫卖，去看看吧"}]
execute as @a if score @s play_main matches 11..12 run scoreboard players add @s play_main 1
