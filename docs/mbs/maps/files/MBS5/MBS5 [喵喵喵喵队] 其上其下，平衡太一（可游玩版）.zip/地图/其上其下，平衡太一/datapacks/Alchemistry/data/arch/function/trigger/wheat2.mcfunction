scoreboard players set result runtime 0
execute store result score result runtime run clear @s minecraft:firework_star[minecraft:custom_data={id:"wheat",m:true}]
scoreboard players operation result runtime *= 2 const
scoreboard players operation money runtime += result runtime
scoreboard players reset @s wheat