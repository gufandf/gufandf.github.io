execute as @e[type=interaction,tag=pot] on target at @s if data entity @s SelectedItem{id:"minecraft:stick"} run function arch:pot/end
execute as @e[type=interaction,tag=pot] run data remove entity @s interaction
execute as @e[type=interaction,tag=flower] on target as @p run function arch:open_shop {shop:"flower"}
execute as @e[type=interaction,tag=flower] run data remove entity @s interaction
execute as @e[type=interaction,tag=material] on target as @p run function arch:sell_wheat
execute as @e[type=interaction,tag=material] run data remove entity @s interaction
execute as @e[type=interaction,tag=material] on attacker as @p run function arch:open_shop {shop:"material"}
execute as @e[type=interaction,tag=material] run data remove entity @s attack
execute as @e[type=interaction,tag=request] positioned 8.5 -59 -13 as @s[x=8.5,y=-59,z=-13,distance=..1] on target run function arch:check_request {index:1}
execute as @e[type=interaction,tag=request] positioned 10.5 -59 -13 as @s[x=10.5,y=-59,z=-13,distance=..1] on target run function arch:check_request {index:2}
execute as @e[type=interaction,tag=request] positioned 12.5 -59 -13 as @s[x=12.5,y=-59,z=-13,distance=..1] on target run function arch:check_request {index:3}
execute as @e[type=interaction,tag=request] positioned 14.5 -59 -13 as @s[x=14.5,y=-59,z=-13,distance=..1] on target run function arch:check_request {index:4}
execute as @e[type=interaction,tag=request] run data remove entity @s interaction
execute store result score world per_second run time query gametime
scoreboard players operation world per_second %= 60 const

execute if score world per_second matches 0 unless entity @a[scores={play_main=6..}] run function arch:play/scene1
#进入炼金区域
scoreboard players set @a[x=40,y=-58,z=20,dx=5,dy=2,dz=3,scores={play_main=6}] play_main 7
execute if score world per_second matches 0 if entity @a[scores={play_main=7..8}] run function arch:play/scene2
scoreboard players set @a[x=37.5,y=-58,z=8.5,distance=..2,scores={play_main=10}] play_main 11
execute if score world per_second matches 0 if entity @a[scores={play_main=11..12}] run function arch:play/scene3
execute as @a[x=12.5,y=-60,z=8.5,distance=..4] unless score @s play1 matches 1.. run scoreboard players set @a play1 1
execute if score world per_second matches 0 if entity @a[scores={play1=1..8}] run function arch:play/scene4
execute as @a[x=24.5,y=-60,z=-9.5,distance=..3] unless score @s play2 matches 1.. run scoreboard players set @a play2 1
execute if score world per_second matches 0 if entity @a[scores={play2=1..7}] run function arch:play/scene5
execute as @a[x=48.5,y=-60,z=-7.5,distance=..4] unless score @s play4 matches 1.. run scoreboard players set @a play4 1
execute if score world per_second matches 0 if entity @a[scores={play4=1..6}] run function arch:play/scene6
scoreboard players set @a[x=11.5,y=-58,z=-12.5,distance=..5,scores={play_main=13}] play_main 14
execute if score world per_second matches 0 if entity @a[scores={play_main=14..15}] run function arch:play/scene7

execute as @a[scores={play_main=16,play1=9,play2=8,play4=7}] run scoreboard players set @s play_main 17
execute if score world per_second matches 0 if entity @a[scores={play_main=17..18}] run function arch:play/scene8

execute if score exp runtime matches 3 run scoreboard players set @a[scores={play_main=..19}] play_main 20
#execute if score exp runtime matches 7 run scoreboard players set @a play_main 20

execute if score world per_second matches 0 if entity @a[scores={play_main=20..21}] run function arch:play/scene9

execute as @a[x=12.5,y=-60,z=8.5,distance=..4] if score @s play1 matches 10 run scoreboard players set @a play1 11
execute as @a[x=24.5,y=-60,z=-9.5,distance=..3] if score @s play2 matches 10 run scoreboard players set @a play2 11
execute as @a[x=48.5,y=-60,z=-7.5,distance=..4] if score @s play4 matches 10 run scoreboard players set @a play4 11
execute if score world per_second matches 0 if entity @a[scores={play1=11..21}] run function arch:play/scene10
execute if score world per_second matches 0 if entity @a[scores={play2=11..14}] run function arch:play/scene11
execute if score world per_second matches 0 if entity @a[scores={play4=11..14}] run function arch:play/scene12

execute if score exp runtime matches 7 run scoreboard players set @a[scores={play_main=..22}] play_main 23
execute if score world per_second matches 0 if entity @a[scores={play_main=23..24}] run function arch:play/scene13

execute as @a[x=12.5,y=-60,z=8.5,distance=..4] if score @s play1 matches 22 if score exp runtime matches 7.. run scoreboard players set @a play1 23
execute as @a[x=24.5,y=-60,z=-9.5,distance=..3] if score @s play1 matches 25 run scoreboard players set @a play1 26
execute if score world per_second matches 0 if entity @a[scores={play1=23..24}] run function arch:play/scene14
execute if score world per_second matches 0 if entity @a[scores={play1=26..31}] run function arch:play/scene15

scoreboard players set @a[scores={play1=..32,end=1..}] play1 33
execute if score world per_second matches 0 if entity @a[scores={play1=33..37}] run function arch:play/scene16

execute if score exp runtime matches ..2 run fill 8 -57 -22 9 -57 -21 oak_log
execute if score exp runtime matches 3.. run fill 8 -57 -22 9 -57 -21 air


execute if score exp runtime matches ..6 run setblock 25 -53 -24 iron_trapdoor{half:top} keep 
execute if score exp runtime matches 7.. run setblock 25 -53 -24 air
execute if score exp runtime matches 7.. as @e[tag=aj.alice.root] run function animated_java:alice/remove/all

execute if score exp runtime matches 7.. run data remove storage arch:requests values[{item:"medicine"}]


execute store result score 你的金钱数 money run scoreboard players get money runtime
execute positioned 8.5 -59 -13 unless entity @e[tag=aj.request.root,distance=..1] rotated 0 0 run \
    function animated_java:request/summon {args: {}}
execute positioned 10.5 -59 -13 unless entity @e[tag=aj.request.root,distance=..1] rotated 0 0 run \
    function animated_java:request/summon {args: {}}
execute positioned 12.5 -59 -13 unless entity @e[tag=aj.request.root,distance=..1] rotated 0 0 run \
    function animated_java:request/summon {args: {}}
execute positioned 14.5 -59 -13 unless entity @e[tag=aj.request.root,distance=..1] rotated 0 0 run \
    function animated_java:request/summon {args: {}}
execute as @a if score @s shop matches 1.. run function arch:trigger/buy
execute as @a if score @s request matches 1.. run function arch:trigger/request
execute as @a if score @s wheat matches 1 run function arch:trigger/wheat1
execute as @a if score @s wheat matches 2.. run function arch:trigger/wheat2

