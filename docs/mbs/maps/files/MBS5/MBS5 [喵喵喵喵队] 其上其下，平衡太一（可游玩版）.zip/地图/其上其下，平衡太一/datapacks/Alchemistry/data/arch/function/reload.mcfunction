scoreboard players set setuped runtime 0

reload
