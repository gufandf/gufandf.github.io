#提取金钱
$execute store result score cost runtime run data get storage arch:shop values[$(index)].cost
#查看是否买得起，如果买得起就购买


#如果买不起
execute unless score money runtime >= cost runtime run tellraw @p {"text":"购买失败！余额不足","color":"red"}

#如果买得起
execute if score money runtime >= cost runtime run tellraw @p {"text":"购买成功！","color":"green"}
#   给商品
$execute if score money runtime >= cost runtime run data modify storage arch:record id set from storage arch:shop values[$(index)].goods
execute if score money runtime >= cost runtime run function arch:give_item with storage arch:record
#   扣钱
execute if score money runtime >= cost runtime run scoreboard players operation money runtime -= cost runtime

#重置自己的shop
scoreboard players reset @s shop