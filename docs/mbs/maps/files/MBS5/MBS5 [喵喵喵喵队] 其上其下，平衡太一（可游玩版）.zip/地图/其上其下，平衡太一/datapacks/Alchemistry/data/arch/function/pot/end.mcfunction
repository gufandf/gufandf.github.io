#结束炼金

#判断能否结束炼金
execute unless score pot runtime matches 2..5 run return fail


#获取当前温度值
execute store result score temperature runtime run data get storage arch:pot temperature

#获取当前质量值
execute store result score weight runtime run data get storage arch:pot weight

#取绝对值
execute if score temperature runtime matches ..0 run scoreboard players operation temperature runtime *= minus1 const
execute if score weight runtime matches ..0 run scoreboard players operation weight runtime *= minus1 const

#相加
scoreboard players operation temperature runtime += weight runtime

#假若炼金成功
execute if score temperature runtime <= tolerance settings run tellraw @p {"text":"炼金成功！","color":"green"}
execute if score temperature runtime <= tolerance settings run playsound minecraft:entity.player.levelup master @p
execute if score temperature runtime <= tolerance settings run function arch:steps/end_give with storage arch:pot
execute if score temperature runtime <= tolerance settings as @a if score @s play_main matches 9 run tellraw @p {"text":"<Elias>:成功啦，我真是天才！"}
#假若炼金失败
execute unless score temperature runtime <= tolerance settings run tellraw @p {"text":"炼金失败！请尝试更改物料重新平衡！","color":"red"}
execute unless score temperature runtime <= tolerance settings run playsound minecraft:entity.player.burp master @p
execute unless score temperature runtime <= tolerance settings as @a if score @s play_main matches 9 run tellraw @p {"text":"<Elias>:别灰心Elias，下次肯定能成功的"}


execute as @a if score @s play_main matches 9 run scoreboard players set @s play_main 10
execute as @a if score @s play_main matches 10 run tellraw @s {"text":"<Elias>:接下来，去外面逛逛吧"}
#重置炼金锅
scoreboard players set pot runtime 0
#通报偏移
scoreboard players operation temperature runtime /= 10 const
tellraw @p {"text":"此次炼金的内容偏移量（偏移量越小说明炼金越成功）：","color":"green","extra":[{"type":"score","score":{"objective":"runtime","name":"temperature"}}]}