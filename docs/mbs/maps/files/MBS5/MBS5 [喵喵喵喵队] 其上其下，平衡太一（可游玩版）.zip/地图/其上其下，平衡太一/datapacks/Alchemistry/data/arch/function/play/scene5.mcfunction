execute unless entity @e[tag=aj.oldman.root] positioned 24.5 -60 -9.5 rotated 90 0 run \
	function animated_java:oldman/summon {args: {}}
execute as @a if score @s play2 matches 2 run tellraw @s [{text:"<???> 是生面孔啊"}]
execute as @a if score @s play2 matches 3 run tellraw @s [{text:"<Elias> 你好，这位老先生，我是Elias，刚刚才搬过来"}]
execute as @a if score @s play2 matches 4 run tellraw @s [{text:"<Cornelius> 我是Cornelius。这里是我开的书店，借阅随意"}]
execute as @a if score @s play2 matches 5 run tellraw @s [{text:"<Elias> 那太好了，这里有关于炼金术的书吗"}]
execute as @a if score @s play2 matches 6 run tellraw @s [{text:"<Cornelius> 炼金术啊，我年轻的时候也搞这玩意。现在年纪大了，搞不动喽。你如果看见了相关的书，尽管拿去用吧"}]
execute as @a if score @s play2 matches 7 run tellraw @s [{text:"<Elias> 太感谢了"}]
execute as @a if score @s play2 matches 1..7 run scoreboard players add @s play2 1
