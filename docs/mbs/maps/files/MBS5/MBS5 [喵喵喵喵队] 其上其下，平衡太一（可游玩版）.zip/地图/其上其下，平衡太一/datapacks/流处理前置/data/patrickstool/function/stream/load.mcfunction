#各命令存储用法解释
#patrickstool:stream/constant_stream 运行过程中创建的新的流。通常用于稍后覆盖patrickstool:stream/this，内部的value为流
#patrickstool:stream/operated 运行过程中被单独拿出来的一个元素，通常是被操作的元素，内部的value为元素，index作为下标，address为地址
#patrickstool:stream/compared 运行过程中被单独拿出来的一个元素，通常用于和上一条作比较，内部的value为元素，index作为下标，address为地址
#patrickstool:stream/record 被用于给宏函数传参的命令存储
#patrickstool:stream/command 被batch方法用于暂存命令

#每一个流处理函数都需要$(address)指定流的地址，该地址应包含一个NBT对象的来源和一个用于在其中搜索的指向流的NBT路径
#某些函数需要指定使用的函数，在没有特殊要求的情况下，被指定的函数应当是宏函数，接受的参数见下文
#由于被传入所使用的函数的参数被放在了命令存储patrickstool:stream/record中，因此如果想额外传参，可以将参数放入patrickstool:stream/record当中，但不要占用value，index，function，length，address，result，resultBatch，first，second和size这些关键字！（若有功能相似的参数想要传入，建议加上前缀）
#被foreach和filter使用的函数函数可以接受value参数、address参数、index参数和length参数。value参数为被执行的对象本身，address为流的地址，index则为对象在流中的下标，而length参数为该流的长度
#被max、min和sort指定的比较器函数不接受value参数，而改为接受first和second参数，这两个参数为流中的两个将要被比较的元素（注意有先后之分）

#访问流中元素的做法：访问 $(address) value[$(index)]

#此记分项用于记录运行过程中的量
scoreboard objectives add stream dummy
#此记分项下各个虚拟玩家的意义，这些虚拟玩家的值可以被任意读取，但请不要修改：
#catche：在求最大值、最小值时使用的缓存下标
#index：在foreach的时候用于记录当前迭代的下标
#length：在foreach的时候用于记录当前流的长度
#size：在limit、skip的时候用于记录将要被保留/跳过的参数数量
#result：在某些读取函数输出（如比较或者filter）的时候用于暂存输出结果的虚拟玩家


#以下操作可能导致严重的bug产生
#   ·胡乱操作上述提到的命令存储和记分项
#   ·输入的地址不是流