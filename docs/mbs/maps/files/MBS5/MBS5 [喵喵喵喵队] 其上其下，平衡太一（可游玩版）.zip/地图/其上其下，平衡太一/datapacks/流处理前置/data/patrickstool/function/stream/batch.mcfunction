#批处理。接受一个字符串address表示地址，一个字符串数组command表示命令，一个字符串数组argus表示传入的参数。不区分function和size。
#如果处理中有返回值的函数（如min_index、max_index和count），该函数的返回值为所有函数返回值之和

#重置record
#   记录command、argus和result
$data modify storage patrickstool:stream/command command set value $(command)
$data modify storage patrickstool:stream/record argus set value $(argus)
data modify storage patrickstool:stream/record resultBatch set value 0
#   将待操作地址缓存
$data modify storage patrickstool:stream/record catche set value "$(address)"
#   设置接下来迭代的函数和地址
data modify storage patrickstool:stream/record function set value "patrickstool:stream/private/batch/step"
data modify storage patrickstool:stream/record address set value "storage patrickstool:stream/command command"
#   重置记分板
scoreboard players set result stream 0
#迭代开始
function patrickstool:stream/foreach with storage patrickstool:stream/record
#返回值
return run data get storage patrickstool:stream/record resultBatch