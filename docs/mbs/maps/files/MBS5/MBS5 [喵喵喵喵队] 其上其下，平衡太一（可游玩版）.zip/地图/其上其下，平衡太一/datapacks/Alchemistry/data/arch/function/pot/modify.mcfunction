#对温度操作
#获取当前温度值
execute store result score temperature runtime run data get storage arch:pot temperature

#获取当前温度修改值
$execute store result score modifier runtime run data get storage arch:items values[{id:"$(id)"}].temperature

#进行运算
scoreboard players operation temperature runtime += modifier runtime

#存回pot
execute store result storage arch:pot temperature int 1 run scoreboard players get temperature runtime



#对质量操作
#获取当前质量值
execute store result score weight runtime run data get storage arch:pot weight

#获取当前质量修改值
$execute store result score modifier runtime run data get storage arch:items values[{id:"$(id)"}].weight

#进行运算
scoreboard players operation weight runtime += modifier runtime

#存回pot
execute store result storage arch:pot weight int 1 run scoreboard players get weight runtime