#需要一个字符串shop指定是哪个商店
#商店项目注册进arch:shop/$(shop)中
#命令存储arch:dialog用于寄存当前的对话框，arch:shop用于寄存当前的商店项目

#读取商店项目
data remove storage arch:shop values
data remove storage arch:dialog dialog
$data modify storage arch:shop values set from storage arch:shop/$(shop) values
$data modify storage patrickstool:stream/record shop set value "$(shop)"
#设置按钮和商店数据
function patrickstool:stream/batch {address:"storage arch:shop values",command:["filter","foreach"],argus:["arch:shop/exp_filter","arch:shop/button"]}
#完善对话框的其他数据
data modify storage arch:dialog dialog merge value {body:[{type:"plain_message",contents:{text:"欢迎来到商店，请挑选商品："}}],title:{text:"商店"},type:"multi_action"}

#设置触发器并打开对话框
dialog clear @s
scoreboard players set @s shop 0
scoreboard players enable @s shop
function arch:dialog/show with storage arch:dialog