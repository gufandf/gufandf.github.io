#重置result为0
scoreboard players set result stream 0
#获取当前对象
$data modify storage patrickstool:stream/record second set value $(value)
#获取对象
#   将当前最值的下标存入record
execute store result storage patrickstool:stream/record index int 1 run scoreboard players get catche stream
#   用record访问最值的对象
function patrickstool:stream/private/get_from_index with storage patrickstool:stream/record
#   将访问到的对象存入first
data modify storage patrickstool:stream/record first set from storage patrickstool:stream/record value
#比较
$execute store result score result stream run function $(comparer) with storage patrickstool:stream/record
#如果first不大于second，说明这一项更大，将缓存的下标设置为这一项的下标
execute unless score result stream matches 1 run scoreboard players operation catche stream = index stream
