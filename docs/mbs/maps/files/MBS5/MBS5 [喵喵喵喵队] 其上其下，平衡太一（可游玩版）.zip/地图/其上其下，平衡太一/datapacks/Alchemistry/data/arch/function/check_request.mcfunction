#打开委托，使用$(index)确认下标

#清空dialog中的内容
data remove storage arch:dialog dialog
data remove storage arch:dialog object
#提取出要处理的内容
$data modify storage arch:dialog object set from storage arch:content_requests values[$(index)]

#转化按钮的信息
#提取名字
function arch:steps/check_request with storage arch:dialog object
#传入下标
$data modify storage arch:dialog object.index set value $(index)
#组合信息
function arch:steps/check_request2 with storage arch:dialog object
#激活记分项
scoreboard players enable @s request
#打开
function arch:dialog/show with storage arch:dialog