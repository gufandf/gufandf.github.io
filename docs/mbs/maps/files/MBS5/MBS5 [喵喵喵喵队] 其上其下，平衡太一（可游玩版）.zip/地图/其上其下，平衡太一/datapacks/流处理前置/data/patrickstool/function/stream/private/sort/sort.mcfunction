#排序的中间步骤

#record初始化
$data modify storage patrickstool:stream/record address set value "$(address)"
$data modify storage patrickstool:stream/record function set value "$(function)"

#如果流的长度为0，排序结束
$execute store result score length stream run function patrickstool:stream/count {address:"$(address)"}
execute if score length stream matches 0 run return 0

#寻找最小的下标
execute store result storage patrickstool:stream/record index int 1 run function patrickstool:stream/min_index with storage patrickstool:stream/record
#处理
function patrickstool:stream/private/sort/step with storage patrickstool:stream/record
$data modify storage patrickstool:stream/record function set value "$(function)"
function patrickstool:stream/private/sort/sort with storage patrickstool:stream/record