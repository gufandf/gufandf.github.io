#返回流中元素个数
$return run data get $(address)