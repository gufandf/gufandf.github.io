#打开卖小麦的对话框
dialog show @s {body:[{type:"plain_message",contents:{text:"收小麦了！2金币一把！"}}],title:{text:"批发商"},type:"multi_action",actions:[{label:{text:"出售1份小麦"},action:{type:"run_command",command:"trigger wheat set 1"}},{label:{text:"出售所有小麦"},action:{type:"run_command",command:"trigger wheat set 2"}}]}
scoreboard players enable @s wheat