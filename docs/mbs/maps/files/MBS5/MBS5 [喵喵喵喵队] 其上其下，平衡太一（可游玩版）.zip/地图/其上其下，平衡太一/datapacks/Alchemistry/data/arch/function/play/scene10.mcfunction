execute as @a if score @s play1 matches 11 as @e[tag=aj.alice.root] run function animated_java:alice/animations/animation_alice_wave/play
execute as @a if score @s play1 matches 12 run tellraw @s [{text:"<Elias> 最近还好吗，Alice小姐"}]
execute as @a if score @s play1 matches 13 run tellraw @s [{text:"<Alice> 咳咳，还好，谢谢您的关心，有劳了"}]
execute as @a if score @s play1 matches 14 as @e[tag=aj.alice.root] run function animated_java:alice/animations/animation_alice_cough/play
execute as @a if score @s play1 matches 15 as @e[tag=aj.alice.root] run function animated_java:alice/animations/animation_alice_sit/play
execute as @a if score @s play1 matches 16 run tellraw @s [{text:"<Elias> 话说，Alice，你得的是什么病啊，能治好吗"}]
execute as @a if score @s play1 matches 17 run tellraw @s [{text:"<Alice> 肺结核，治不好的"}]
execute as @a if score @s play1 matches 18 run tellraw @s [{text:"<Elias> 抱歉……"}]
execute as @a if score @s play1 matches 19 run tellraw @s [{text:"<Alice> 没关系，我已经习惯了，至少还有药物可以缓解"}]
execute as @a if score @s play1 matches 20 run tellraw @s [{text:"<Elias> 我听说用贤者之石可以炼出万灵药，什么病都可以治好，到时候真炼出来了我就给你"}]
execute as @a if score @s play1 matches 21 run tellraw @s [{text:"<Alice> 真的吗！那太好了！"}]
execute as @a if score @s play1 matches 11..21 run scoreboard players add @s play1 1
