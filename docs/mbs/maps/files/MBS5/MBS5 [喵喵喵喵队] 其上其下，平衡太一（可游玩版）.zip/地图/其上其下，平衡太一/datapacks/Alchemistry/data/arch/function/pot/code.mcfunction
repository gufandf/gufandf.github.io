#检测匹配配方

#假若能成功匹配配方
$execute if data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run tellraw @p {"text":"存在匹配的配方，炼金开始！\n提示：你只能再放入3个材料！","color":"green"}
$execute if data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run data modify storage arch:pot result set from storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}].result
$execute if data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run data modify storage arch:pot temperature set from storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}].temperature
$execute if data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run data modify storage arch:pot weight set from storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}].weight
$execute if data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run playsound minecraft:item.trident.thunder master @p
#假若不能成功匹配配方
$execute unless data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run tellraw @p {"text":"配方匹配失败！","color":"red"}
$execute unless data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run scoreboard players set pot runtime 0
$execute unless data storage arch:recipes values.[{m1:"$(m1)",m2:"$(m2)"}] run playsound minecraft:block.anvil.destroy master @p