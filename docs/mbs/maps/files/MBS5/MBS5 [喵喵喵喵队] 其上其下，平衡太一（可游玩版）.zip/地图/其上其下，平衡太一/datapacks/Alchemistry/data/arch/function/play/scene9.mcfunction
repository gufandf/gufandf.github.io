
execute as @a if score @s play_main matches 20 run tellraw @s [{text:"<Elias> 在这几天里，做了不少委托呢，帮了大家不少忙"}]
execute as @a if score @s play_main matches 21 run tellraw @s [{text:"<Elias> 去看看大家怎么样了吧"}]
execute as @a if score @s play_main matches 21 run title @s title [{text:"其上其下，平衡太一"}]
execute as @a if score @s play_main matches 21 run title @s subtitle [{text:"第二章：金属"}]
execute as @a if score @s play_main matches 21 run scoreboard players set @s play1 10

execute as @a if score @s play_main matches 21 run scoreboard players set @s play2 10

execute as @a if score @s play_main matches 21 run scoreboard players set @s play4 10
execute as @a if score @s play_main matches 20..21 run scoreboard players add @s play_main 1
