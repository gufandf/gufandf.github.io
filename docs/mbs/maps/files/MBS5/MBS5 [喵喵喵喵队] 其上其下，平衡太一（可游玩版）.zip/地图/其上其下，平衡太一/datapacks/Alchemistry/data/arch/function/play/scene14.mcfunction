execute as @a if score @s play1 matches 23 if score @s play2 matches ..24 if score @s play2 matches ..24 run tellraw @s [{text:"<Elias> Alice小姐人呢"}]
execute as @a if score @s play1 matches 24 if score @s play2 matches ..24 if score @s play2 matches ..24 run tellraw @s [{text:"<Elias> 去问问吧"}]
execute as @a if score @s play1 matches 23..24 run scoreboard players add @s play1 1
