#这个记分项记录运行时的全局变量
scoreboard objectives add runtime dummy
#这个记分项记录玩家设置的全局变量
scoreboard objectives add settings dummy

#这个记分项是杂货商店触发器
#scoreboard objectives add shop_material trigger
#这个记分项是花店触发器
#scoreboard objectives add shop_flower trigger

#这个记分项是商店触发器
scoreboard objectives add shop trigger
#这个记分项是委托触发器
scoreboard objectives add request trigger
#这个记分项是卖小麦触发器
scoreboard objectives add wheat trigger
#这个记分项是结局触发器
scoreboard objectives add end trigger

say 重加载成功
#这个记分项记录常量
scoreboard objectives add const dummy
scoreboard players set minus1 const -1
scoreboard players set 2 const 2
scoreboard players set 10 const 10

scoreboard players set 60 const 60
#注册剧情进度计分项
scoreboard objectives add play_main dummy "主剧情进度"
scoreboard objectives add play1 dummy "Alice剧情进度"
scoreboard objectives add play2 dummy "书店老板剧情进度"
scoreboard objectives add play3 dummy "房东剧情进度"
scoreboard objectives add play4 dummy "杂货铺老板剧情进度"
scoreboard objectives add per_second dummy
scoreboard objectives add money dummy "现有金钱数量"
scoreboard objectives setdisplay sidebar money
#如果游戏尚未初始化则初始化
execute unless score setup runtime matches 1 run function arch:runtime/setup

#最重要的饱和
effect give @a minecraft:saturation infinite 2 true



