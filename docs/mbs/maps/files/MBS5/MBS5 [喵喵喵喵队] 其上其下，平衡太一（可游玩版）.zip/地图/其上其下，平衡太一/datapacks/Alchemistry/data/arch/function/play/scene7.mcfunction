
execute as @a if score @s play_main matches 14 run tellraw @s [{text:"<Elias> 看来这里是城镇的中心，这里有一个公告栏，去看看吧"}]
execute as @a if score @s play_main matches 15 run tellraw @s [{text:"<Elias> 貌似可以在这里提交物品来换取赏金，赏金又可以去商店买炼金素材"}]
execute as @a if score @s play_main matches 14..15 run scoreboard players add @s play_main 1
