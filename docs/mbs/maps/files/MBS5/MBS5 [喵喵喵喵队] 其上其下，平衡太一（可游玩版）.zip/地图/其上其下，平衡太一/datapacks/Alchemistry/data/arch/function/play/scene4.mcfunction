execute unless entity @e[tag=aj.alice.root] positioned 12.5 -60 8.5 rotated -180 0 run \
	function animated_java:alice/summon {args: {}}
    
execute unless entity @e[tag=flower] positioned 12.5 -60 8.5 rotated 0 0 run summon interaction ~ ~ ~ {Tags:["flower"]}
execute as @a if score @s play1 matches 2 run tellraw @s [{text:"<???> 先生，要买花吗"}]
execute as @a if score @s play1 matches 3 run tellraw @s [{text:"<Elias> 原来是一位可爱的小姐在卖花啊。你好，这位小姐，我能否有幸知道你的名字"}]
execute as @a if score @s play1 matches 4 run tellraw @s [{text:"<Alice> 我的名字是Alice。先生您呢"}]
execute as @a if score @s play1 matches 5 run tellraw @s [{text:"<Elias> 我是Elias，最近刚搬过来的炼金术士"}]
execute as @a if score @s play1 matches 6 run tellraw @s [{text:"<Alice> 是新邻居啊，这束花送给您，就当见面礼了，咳咳"}]
execute as @a if score @s play1 matches 6 run function arch:give_item {id:"rose_bush"}
execute as @a if score @s play1 matches 6 as @e[tag=aj.alice.root] run function animated_java:alice/animations/animation_alice_cough/play
execute as @a if score @s play1 matches 7 run tellraw @s [{text:"<Elias> 感谢你，Alice小姐，有空我会来光顾花店的"}]
execute as @a if score @s play1 matches 7 as @e[tag=aj.alice.root] run function animated_java:alice/animations/animation_alice_wave/play

execute as @a if score @s play1 matches 8 as @e[tag=aj.alice.root] run function animated_java:alice/animations/animation_alice_sit/play
execute as @a if score @s play1 matches 1..8 run scoreboard players add @s play1 1
