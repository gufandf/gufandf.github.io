#处理完成委托的逻辑

#记录委托的物品
data modify storage arch:record id set from storage arch:dialog object.item
#检查并清除
function arch:steps/clear with storage arch:record
#检查委托是否成功
execute unless score result runtime matches 1 run tellraw @p {"text":"未持有委托道具","color":"red"}

execute if score result runtime matches 1 run tellraw @p {"text":"委托完成了！","color":"green"}
execute if score result runtime matches 1 run function arch:steps/delete_request with storage arch:dialog object
execute if score result runtime matches 1 store result score transform runtime run data get storage arch:dialog object.money
execute if score result runtime matches 1 run scoreboard players operation money runtime += transform runtime
execute if score result runtime matches 1 store result score transform runtime run data get storage arch:dialog object.reward
execute if score result runtime matches 1 run scoreboard players operation exp runtime += transform runtime
execute if score result runtime matches 1 run function arch:request/add_request

scoreboard players reset @s request