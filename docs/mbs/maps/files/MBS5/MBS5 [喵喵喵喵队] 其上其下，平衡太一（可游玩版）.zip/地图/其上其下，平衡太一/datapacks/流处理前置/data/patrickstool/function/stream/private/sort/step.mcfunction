$data modify storage patrickstool:stream/constant_stream value append from $(address)[$(index)]
$data remove $(address)[$(index)]