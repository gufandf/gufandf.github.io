#清空先前的数据
data remove storage arch:transform object
#复制数据
$data modify storage arch:transform object set value $(value)
#将所需的exp复制到记分板上
execute store result score exp_filter runtime run data get storage arch:transform object.exp
#进行比较
execute if score exp runtime >= exp_filter runtime run return 1
return fail