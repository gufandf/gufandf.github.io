execute as @a unless score @s play_main matches 1.. run tp 41 -54 24
execute as @a unless score @s play_main matches 1.. run tellraw @s [{text:"<Elias> 今天是搬到镇子上的第一天，收拾我的炼金工具可废了我不少功夫，还好房东帮了我不少忙，还免了我的租金。"}]
execute as @a if score @s play_main matches 1 run tellraw @s [{text:"你是一名炼金术士，名为Elias，为了研究炼金术而来到这个城镇"}]
execute as @a if score @s play_main matches 2 run tellraw @s [{text:"房东Martha为你免了租金，只要求你在这段日子多陪陪她"}]
execute as @a if score @s play_main matches 3 run tellraw @s [{text:"<Elias> Martha太太是这样说的：'反正这件房间空着也是空着，有人来住的话，还更热闹一点'"}]
execute as @a if score @s play_main matches 4 run tellraw @s [{text:"<Elias> 真是帮大忙了，我正愁没有地方住呢。有着这样的条件，我一定会炼出贤者之石，成为历史中的炼金术士’"}]
execute as @a if score @s play_main matches 5 run tellraw @s [{text:"<Elias> 不说这么多了，先下楼去看看我宝贵的器材吧"}]
execute as @a if score @s play_main matches 5 run title @s title [{text:"其上其下，平衡太一"}]
execute as @a if score @s play_main matches 5 run title @s subtitle [{text:"第一章：初生活"}]
execute as @a unless score @s play_main matches 6.. run scoreboard players add @s play_main 1
