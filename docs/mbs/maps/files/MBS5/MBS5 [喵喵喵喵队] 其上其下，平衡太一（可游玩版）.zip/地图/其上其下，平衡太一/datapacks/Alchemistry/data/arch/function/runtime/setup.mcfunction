#调整记分板
scoreboard players set pot runtime 0
scoreboard players set setup runtime 1
scoreboard players set money runtime 100
scoreboard players set exp runtime 0

scoreboard players set tolerance settings 20



#注册物品
data remove storage arch:items values
#data modify storage arch:items values append value {id:"test",name:"test_",weight:0,temperature:0,model:"null"}
#data modify storage arch:items values append value {id:"test2",name:"test_2",weight:1,temperature:-1,model:"null"}
data modify storage arch:items values append value {id:"philosopher_stone",name:"贤者之石",weight:100000,temperature:100000,model:"philosopher_stone"}
data modify storage arch:items values append value {id:"gold",name:"金",temperature:0,weight:0,model:"gold"}
data modify storage arch:items values append value {id:"philosophical_sulphur",name:"哲人硫",temperature:-5000,weight:-3000,model:"philosophical_sulphur"}
data modify storage arch:items values append value {id:"philosophical_mercury",name:"哲人汞",temperature:-4000,weight:-5000,model:"philosophical_mercury"}
data modify storage arch:items values append value {id:"philosophical_salt",name:"哲人盐",temperature:-3000,weight:-4000,model:"philosophical_salt"}
data modify storage arch:items values append value {id:"green_lion",name:"绿狮",temperature:0,weight:0,model:"green_lion"}
data modify storage arch:items values append value {id:"lead",name:"铅",temperature:0,weight:-400,model:"lead"}
data modify storage arch:items values append value {id:"tin",name:"锡",temperature:300,weight:200,model:"tin"}
data modify storage arch:items values append value {id:"iron",name:"铁",temperature:-300,weight:200,model:"iron"}
data modify storage arch:items values append value {id:"copper",name:"铜",temperature:300,weight:-200,model:"copper"}
data modify storage arch:items values append value {id:"mercury",name:"汞",temperature:-300,weight:-200,model:"mercury"}
data modify storage arch:items values append value {id:"silver",name:"银",temperature:0,weight:400,model:"silver"}
data modify storage arch:items values append value {id:"sulphur",name:"硫磺",temperature:10,weight:30,model:"sulphur"}
data modify storage arch:items values append value {id:"realgar",name:"雄黄",temperature:20,weight:20,model:"realgar"}
data modify storage arch:items values append value {id:"saltpeter",name:"硝石",temperature:30,weight:10,model:"saltpeter"}
data modify storage arch:items values append value {id:"saltpeter_earth",name:"硝土",temperature:-10,weight:30,model:"saltpeter_earth"}
data modify storage arch:items values append value {id:"cinnabar",name:"朱砂",temperature:-20,weight:20,model:"cinnabar"}
data modify storage arch:items values append value {id:"coal",name:"煤",temperature:-30,weight:10,model:"coal"}
data modify storage arch:items values append value {id:"wheat",name:"小麦",temperature:-10,weight:-30,model:"wheat"}
data modify storage arch:items values append value {id:"salt",name:"盐",temperature:-20,weight:-20,model:"salt"}
data modify storage arch:items values append value {id:"clay",name:"粘土",temperature:-30,weight:-10,model:"clay"}
data modify storage arch:items values append value {id:"poppy",name:"虞美人",temperature:10,weight:-30,model:"poppy"}
data modify storage arch:items values append value {id:"blue_orchid",name:"兰花",temperature:20,weight:-20,model:"blue_orchid"}
data modify storage arch:items values append value {id:"rose_bush",name:"玫瑰丛",temperature:30,weight:-10,model:"rose_bush"}
data modify storage arch:items values append value {id:"blaze_core",name:"焰核",temperature:60,weight:0,model:"blaze_core"}
data modify storage arch:items values append value {id:"medicine",name:"简易药物",temperature:0,weight:0,model:"medicine"}
data modify storage arch:items values append value {id:"leather",name:"皮革",temperature:0,weight:0,model:"leather"}
data modify storage arch:items values append value {id:"bone_meal",name:"骨粉",temperature:0,weight:0,model:"bone_meal"}


#注册配方
data remove storage arch:recipes values
#data modify storage arch:recipes values append value {m1:"test",m2:"test",weight:0,temperature:0,result:"test"}
#data modify storage arch:recipes values append value {m1:"test",m2:"test2",weight:-1,temperature:1,result:"test2"}

data modify storage arch:recipes values append value {m1:"gold",m2:"green_lion",weight:12000,temperature:12000,result:"philosopher_stone"}
data modify storage arch:recipes values append value {m1:"mercury",m2:"gold",weight:0,temperature:600,result:"philosophical_mercury"}
data modify storage arch:recipes values append value {m1:"salt",m2:"gold",weight:-400,temperature:600,result:"philosophical_salt"}
data modify storage arch:recipes values append value {m1:"sulphur",m2:"gold",weight:0,temperature:-600,result:"philosophical_sulphur"}
data modify storage arch:recipes values append value {m1:"sulphur",m2:"copper",weight:400,temperature:-600,result:"green_lion"}
data modify storage arch:recipes values append value {m1:"copper",m2:"clay",weight:60,temperature:60,result:"sulphur"}
data modify storage arch:recipes values append value {m1:"cinnabar",m2:"coal",weight:60,temperature:-60,result:"mercury"}
data modify storage arch:recipes values append value {m1:"clay",m2:"saltpeter_earth",weight:-60,temperature:60,result:"salt"}
data modify storage arch:recipes values append value {m1:"realgar",m2:"wheat",weight:-60,temperature:-60,result:"medicine"}
data modify storage arch:recipes values append value {m1:"wheat",m2:"salt",weight:30,temperature:10,result:"leather"}
data modify storage arch:recipes values append value {m1:"saltpeter_earth",m2:"clay",weight:20,temperature:20,result:"bone_meal"}
data modify storage arch:recipes values append value {m1:"coal",m2:"cinnabar",weight:0,temperature:0,result:"blaze_core"}



#注册商品
data remove storage arch:shop/material values
data remove storage arch:shop/flower values
#data modify storage arch:shop/material values append value {goods:"test",cost:10,exp:0}
#data modify storage arch:shop/material values append value {goods:"test2",cost:20,exp:10}


data modify storage arch:shop/material values append value {goods:"lead",cost:10,exp:3}
data modify storage arch:shop/material values append value {goods:"tin",cost:10,exp:3}
data modify storage arch:shop/material values append value {goods:"iron",cost:10,exp:3}
data modify storage arch:shop/material values append value {goods:"copper",cost:10,exp:3}
data modify storage arch:shop/material values append value {goods:"silver",cost:10,exp:3}
data modify storage arch:shop/material values append value {goods:"realgar",cost:5,exp:0}
data modify storage arch:shop/material values append value {goods:"saltpeter",cost:5,exp:0}
data modify storage arch:shop/material values append value {goods:"saltpeter_earth",cost:5,exp:0}
data modify storage arch:shop/material values append value {goods:"cinnabar",cost:5,exp:0}
data modify storage arch:shop/material values append value {goods:"coal",cost:5,exp:0}
data modify storage arch:shop/material values append value {goods:"clay",cost:5,exp:0}
data modify storage arch:shop/material values append value {goods:"gold",cost:50,exp:7}

data modify storage arch:shop/flower values append value {goods:"poppy",cost:2,exp:0}
data modify storage arch:shop/flower values append value {goods:"blue_orchid",cost:2,exp:0}
data modify storage arch:shop/flower values append value {goods:"rose_bush",cost:3,exp:0}



#注册委托
data remove storage arch:requests values
#data modify storage arch:requests values append value {item:"test",lore:"测试1",exp:0,money:1000,reward:10}
#data modify storage arch:requests values append value {item:"test2",lore:"测试2",exp:0,money:1000,reward:10}


data modify storage arch:requests values append value {item:"bone_meal",lore:"最近收成欠佳，我需要骨粉用于农作 \n ——Giles",exp:0,money:100,reward:1}
data modify storage arch:requests values append value {item:"medicine",lore:"我需要一些药物来稳定病情 \n ——Alice",exp:0,money:200,reward:1}
data modify storage arch:requests values append value {item:"leather",lore:"我有些书皮坏了，急需皮革来修复它 \n ——Cornelius",exp:3,money:150,reward:1}
data modify storage arch:requests values append value {item:"salt",lore:"需要盐 \n ——Tess",exp:0,money:100,reward:1}
data modify storage arch:requests values append value {item:"medicine",lore:"感谢上次的药物，不至于让死神带走我的灵魂，这次我依旧需要一些药物 \n ——Alice",exp:3,money:400,reward:1}
data modify storage arch:requests values append value {item:"mercury",lore:"我需要汞来制作温度计 \n ——Bram",exp:3,money:400,reward:1}
data modify storage arch:requests values append value {item:"sulphur",lore:"诊所需要硫磺来治疗皮肤病 \n ——Rafe",exp:3,money:350,reward:1}
data modify storage arch:requests values append value {item:"sulphur",lore:"我需要用来消毒 \n ——Rafe",exp:7,money:1000,reward:1}
data modify storage arch:requests values append value {item:"leather",lore:"我的鞋子在下地时破了，需要缝补 \n ——Giles",exp:3,money:400,reward:1}
data modify storage arch:requests values append value {item:"salt",lore:"需要更多的盐 \n ——Tess",exp:7,money:500,reward:1}



#刷新委托
data remove storage arch:content_requests values
function arch:request/add_request
function arch:request/add_request
function arch:request/add_request
function arch:request/add_request
function arch:request/add_request


say 数据包重载中……