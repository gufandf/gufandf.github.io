$data modify storage arch:record item set from storage arch:items values.[{id:"$(id)"}]
function arch:steps/give_item with storage arch:record item