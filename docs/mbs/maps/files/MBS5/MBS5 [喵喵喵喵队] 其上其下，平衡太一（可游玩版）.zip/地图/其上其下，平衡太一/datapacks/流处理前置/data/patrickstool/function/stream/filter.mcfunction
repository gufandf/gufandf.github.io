#用指定条件过滤流，需要一个function参数指定用于当作条件的函数,若函数返回1则该元素可以保留，否则该元素从流中被剔除

data modify storage patrickstool:stream/constant_stream {} merge value {value:[]}
#data modify storage patrickstool:stream/operated {} set value {}

#此处重新设置迭代逻辑
#data modify storage patrickstool:stream/record {} set value {}
scoreboard players set index stream 0
$execute store result storage patrickstool:stream/record length int 1 run function patrickstool:stream/count {address:"$(address)"}
data modify storage patrickstool:stream/record index set value 0
$data modify storage patrickstool:stream/record function set value "$(function)"
$data modify storage patrickstool:stream/record address set value "$(address)"
function patrickstool:stream/private/filter/foreachstep with storage patrickstool:stream/record


$data modify $(address) set from storage patrickstool:stream/constant_stream value