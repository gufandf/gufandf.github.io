#设置参数
$data modify storage patrickstool:stream/record function set from storage patrickstool:stream/record argus[$(index)]
$data modify storage patrickstool:stream/record size set from storage patrickstool:stream/record argus[$(index)]
$data modify storage patrickstool:stream/record address set value "$(catche)"



#重置记分板
scoreboard players set catche stream 0
#运行
$execute store result score catche stream run function patrickstool:stream/$(value) with storage patrickstool:stream/record

#断点
#$say $(resultBatch)
#$say $(value)

#读取result
$scoreboard players set result stream $(resultBatch)
#处理结果
scoreboard players operation result stream += catche stream
#记录返回值
execute store result storage patrickstool:stream/record resultBatch int 1 run scoreboard players get result stream
#还原record
data modify storage patrickstool:stream/record function set value "patrickstool:stream/private/batch/step"
data modify storage patrickstool:stream/record address set value "storage patrickstool:stream/command"

