#清空先前的数据
data remove storage arch:transform object
#复制数据
$data modify storage arch:transform object set value $(value)
$data modify storage arch:transform object.shop set value "$(shop)"
$data modify storage arch:transform object.index set value $(index)

#添加新的按钮
function arch:steps/button with storage arch:transform object