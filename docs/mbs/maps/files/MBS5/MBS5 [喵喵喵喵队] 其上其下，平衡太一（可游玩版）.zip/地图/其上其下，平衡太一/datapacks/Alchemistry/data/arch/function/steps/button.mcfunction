#充分预备
data remove storage arch:dialog object
data remove storage arch:dialog record
#提取货物名称和金钱，然后把它们注册进dialog的object当中
$data modify storage arch:dialog record.name set from storage arch:items values.[{id:"$(goods)"}].name
$data modify storage arch:dialog record.cost set value $(cost)
#此处我们设置下标+1
$scoreboard players set index runtime $(index)
scoreboard players add index runtime 1
execute store result storage arch:dialog record.index int 1 run scoreboard players get index runtime
#设置按钮
function arch:steps/button2 with storage arch:dialog record


#将按钮加进对话框
data modify storage arch:dialog dialog.actions append from storage arch:dialog object