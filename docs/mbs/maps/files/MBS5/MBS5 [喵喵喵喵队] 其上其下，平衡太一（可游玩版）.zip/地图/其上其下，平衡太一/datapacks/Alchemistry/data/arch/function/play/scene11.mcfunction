execute as @a if score @s play2 matches 11 run tellraw @s [{text:"<Cornelius> 是你啊，最近你可帮小镇做了不少事呢，镇民们都称呼你为大好人呢"}]
execute as @a if score @s play2 matches 12 run tellraw @s [{text:"<Elias> 不敢当，Cornelius先生"}]
execute as @a if score @s play2 matches 13 run tellraw @s [{text:"<Cornelius> 对了，二楼装修好了，你需要新的书可以去上面找"}]
execute as @a if score @s play2 matches 14 run tellraw @s [{text:"<Elias> 感谢！"}]
execute as @a if score @s play2 matches 11..14 run scoreboard players add @s play2 1
