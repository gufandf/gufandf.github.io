#跳过流中前$(size)个元素

#清空缓存流
data modify storage patrickstool:stream/constant_stream {} merge value {value:[]}
$scoreboard players set size stream $(size)
$function patrickstool:stream/foreach {address:"$(address)",function:"patrickstool:stream/private/skip/step"}
$data modify $(address) set from storage patrickstool:stream/constant_stream value