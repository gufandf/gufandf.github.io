execute as @a if score @s play1 matches 26 run tellraw @s [{text:"<Elias> Cornelius先生，Alice人呢"}]
execute as @a if score @s play1 matches 27 run tellraw @s [{text:"<Cornelius> 她……前不久去世了"}]
execute as @a if score @s play1 matches 28 run tellraw @s [{text:"<Elias> 怎么会……"}]
execute as @a if score @s play1 matches 29 run tellraw @s [{text:"<Cornelius> 阁楼的禁书区开放了，那些都是我年轻的的时候珍藏的书，只不过教会的人不允许。你可以去看看"}]
execute as @a if score @s play1 matches 30 run tellraw @s [{text:"<Elias> 我会的"}]
execute as @a if score @s play1 matches 31 run tellraw @s [{text:"<Cornelius> 哎，真是相似的命运，但你或许能炼出贤者之石，抹平你自己的遗憾呢"}]
execute as @a if score @s play1 matches 26..31 run scoreboard players add @s play1 1
