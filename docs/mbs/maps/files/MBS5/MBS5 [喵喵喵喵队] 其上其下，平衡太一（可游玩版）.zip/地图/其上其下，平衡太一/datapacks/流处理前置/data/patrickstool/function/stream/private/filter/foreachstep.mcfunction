#foreach的中间步骤。需要一个function字符串指定要执行的函数

#提取数据
$scoreboard players set index stream $(index)
$scoreboard players set length stream $(length)
#判断运行结束
execute if score index stream >= length stream run return fail
#提取元素
#   重置record
#data modify storage patrickstool:stream/record {} set value {}
#   用下标访问获取对象
$data modify storage patrickstool:stream/record address set value "$(address)"
execute store result storage patrickstool:stream/record index int 1 run scoreboard players get index stream
function patrickstool:stream/private/get_from_index with storage patrickstool:stream/record
#   将下标一并打包
#execute store result storage patrickstool:stream/operated index int 1 run scoreboard players get index stream

#进行过滤操作，如果返回为1则不被过滤
#$function patrickstool:stream/private/filter/filterstep with storage patrickstool:stream/operated
scoreboard players set result stream 0
$execute store result score result stream run function $(function) with storage patrickstool:stream/record
execute if score result stream matches 1 run data modify storage patrickstool:stream/constant_stream value append from storage patrickstool:stream/record value

#下标加一
scoreboard players add index stream 1
#打包
$data modify storage patrickstool:stream/record length set value $(length)
$data modify storage patrickstool:stream/record function set value "$(function)"
$data modify storage patrickstool:stream/record address set value "$(address)"
execute store result storage patrickstool:stream/record index int 1 run scoreboard players get index stream

#下一次循环
function patrickstool:stream/private/filter/foreachstep with storage patrickstool:stream/record