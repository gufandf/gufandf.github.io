#找出最小值并返回下标，需要一个function指定比较器，接受first和second两个参数，返回1表示前者比后者大

#record初始化
$data modify storage patrickstool:stream/record address set value "$(address)"
$data modify storage patrickstool:stream/record comparer set value "$(function)"
data modify storage patrickstool:stream/record function set value "patrickstool:stream/private/sort/min"

#重置缓存下标
scoreboard players set catche stream 0
#运行
function patrickstool:stream/foreach with storage patrickstool:stream/record
#返回缓存的下标
return run scoreboard players get catche stream