

execute as @a if score @s play_main matches 7 run tellraw @s [{text:"<Elias> 看！这个锅就是最重要的炼金工具。只要往里面放入§g两个材料作为基底，再通过三个材料进行温度和质量的调整的可以炼金啦"}]
execute as @a if score @s play_main matches 8 run tellraw @s [{text:"<Elias> 嗯，先来炼一份盐恢复一下手感吧，忙着搬家最近都没有炼金了"}]
execute as @a if score @s play_main matches 8 run function arch:give_item {id:"clay"}
execute as @a if score @s play_main matches 8 run function arch:give_item {id:"saltpeter_earth"}
execute as @a if score @s play_main matches 8 run function arch:give_item {id:"saltpeter_earth"}
execute as @a if score @s play_main matches 8 run function arch:give_item {id:"cinnabar"}
execute as @a if score @s play_main matches 8 run function arch:give_item {id:"coal"}
execute as @a if score @s play_main matches 8 run give @s stick[minecraft:can_break={blocks:"wheat"}]
execute as @a if score @s play_main matches 8 run give @s diamond_hoe[minecraft:can_break={blocks:"wheat"},minecraft:unbreakable={}]
execute as @a if score @s play_main matches 8 run tellraw @s [{text:"先将黏土和硝土作为基底放入锅中，随后放入另一份硝土、朱砂和煤进行调整吧。盐需要低温度和高质量，而这三样物质刚好可以满足条件。别忘了最后还要用木棍搅拌。",color:gold},{text:"记住，基底的材料和顺序很重要，而剩下三个材料只是用来调整温度和质量的",color:"red"}]
execute as @a if score @s play_main matches 7..8 run scoreboard players add @s play_main 1