execute unless entity @e[tag=aj.midage.root] positioned 49.5 -60 -7.5 rotated 0 0 run \
	function animated_java:midage/summon {args: {}}
execute unless entity @e[tag=material] positioned 49.5 -60 -7.5 rotated 0 0 run summon interaction ~ ~ ~ {Tags:["material"]}
execute as @a if score @s play4 matches 2 run tellraw @s [{text:"<???> 你好，要买东西吗"}]
execute as @a if score @s play4 matches 3 run tellraw @s [{text:"<Elias> 你好，这里是杂货铺？"}]
execute as @a if score @s play4 matches 4 run tellraw @s [{text:"<Percival> 我看见了，你刚刚搬过来的吧。自我介绍一下，我是Percival。"}]
execute as @a if score @s play4 matches 5 run tellraw @s [{text:"<Elias> 嗯……好多东西感觉都可以拿来当素材"}]
execute as @a if score @s play4 matches 6 run tellraw @s [{text:"<Percival> 看上了什么就和我说吧，顺便一提，你也可以在我这里卖麦子（提示：左键购买右键出售）"}]
execute as @a if score @s play4 matches 1..6 run scoreboard players add @s play4 1
