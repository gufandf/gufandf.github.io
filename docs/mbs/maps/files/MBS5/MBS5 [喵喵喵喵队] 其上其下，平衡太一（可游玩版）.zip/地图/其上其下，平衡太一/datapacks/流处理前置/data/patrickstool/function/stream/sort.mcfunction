#使用给定的比较器，将流顺序排序

#record初始化
$data modify storage patrickstool:stream/record address set value "$(address)"
$data modify storage patrickstool:stream/record function set value "$(function)"

#constant_stream初始化
data modify storage patrickstool:stream/constant_stream {} merge value {value:[]}

#开始运行
function patrickstool:stream/private/sort/sort with storage patrickstool:stream/record
#复制
$data modify $(address) set from storage patrickstool:stream/constant_stream value

#断点
#say sort break