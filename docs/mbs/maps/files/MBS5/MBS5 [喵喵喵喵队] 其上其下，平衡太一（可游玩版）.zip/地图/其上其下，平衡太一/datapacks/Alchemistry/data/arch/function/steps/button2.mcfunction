#设置按钮的文本
$data modify storage arch:dialog object.label set value "$(name) 售价$(cost)金币"
#设置按钮的操作
$data modify storage arch:dialog object.action set value {type:"run_command",command:"trigger shop set $(index)"}