#用于将流中指定位置的元素提取到record中，需要一个index参数指明下标
$data modify storage patrickstool:stream/record value set from $(address)[$(index)]