
execute as @a if score @s play_main matches 17 run tellraw @s [{text:"<Elias> 已经逛的差不多啦，总之，可以在花店的Alice和杂货铺的Percival那里购买炼金素材。公告栏那里可以提交物品来换取赏金。"}]
execute as @a if score @s play_main matches 18 run tellraw @s [{text:"<Elias> 如果没有钱的话，就去家的田里收割麦子卖掉吧。炼金配方可以去书店找。"}]
execute as @a if score @s play_main matches 17..18 run scoreboard players add @s play_main 1
