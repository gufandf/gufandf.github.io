#获取流中前几个元素，需要用size指定元素数量

#清空缓存流
data modify storage patrickstool:stream/constant_stream {} merge value {value:[]}
$scoreboard players set size stream $(size)
$function patrickstool:stream/foreach {address:"$(address)",function:"patrickstool:stream/private/limit/step"}
$data modify $(address) set from storage patrickstool:stream/constant_stream value

#断点
#say limit break