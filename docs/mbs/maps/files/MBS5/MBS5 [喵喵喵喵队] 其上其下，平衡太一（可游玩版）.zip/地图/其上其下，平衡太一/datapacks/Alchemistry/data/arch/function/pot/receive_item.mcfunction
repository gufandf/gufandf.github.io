#物料+1
scoreboard players add pot runtime 1
#记录自身的id
data modify storage arch:record id set from entity @s Item.components."minecraft:custom_data".id

#对m1和m2进行处理
execute if score pot runtime matches 1 run function arch:pot/m1 with storage arch:record
execute if score pot runtime matches 2 run function arch:pot/m2 with storage arch:record

#对m2进行密码子处理
execute if score pot runtime matches 2 run function arch:pot/code with storage arch:pot


#对m3、m4和m5进行处理
execute if score pot runtime matches 3..5 run function arch:pot/modify with storage arch:record

#清除自身
kill @s