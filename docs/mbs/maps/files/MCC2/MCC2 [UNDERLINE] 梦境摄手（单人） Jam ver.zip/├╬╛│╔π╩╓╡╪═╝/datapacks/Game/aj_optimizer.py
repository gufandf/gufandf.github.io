from pathlib import Path
from itertools import *

import numpy as np

ROOT_DIR = Path(__file__).parent

if not (ROOT_DIR / "pack.mcmeta").exists():
    LookupError("Please place this .py file in the same directory as pack.mcmeta.")
elif not (ROOT_DIR / "data.ajmeta").exists():
    LookupError("Can't find data.ajmeta.")

FUNCTION_DIR = ROOT_DIR / "data" / "animated_java" / "function"

RIG_DIRS = [item for item in FUNCTION_DIR.iterdir() if item.is_dir() and item.name != "global"]

NEED_MODIFIED_FUNCTIONS = [
    Path("apply_frame.mcfunction"),
    Path("next_frame.mcfunction"),
    Path("tween.mcfunction"),
    Path("zzz","on_tick.mcfunction"),
    Path("zzz","apply_frame.mcfunction"),
]
 

def get_animations(rig_dir):
    return (item for item in (rig_dir / "animations").iterdir() if item.is_dir())

def modify_rig_dir(rig_dir):
    for animation_dir, need_modified_function in product(get_animations(rig_dir), NEED_MODIFIED_FUNCTIONS):
        function_path = animation_dir / need_modified_function
        with open(function_path, 'r+') as file:
            content = file.read()
            if need_modified_function.name == "on_tick.mcfunction":
                modified_content = content.replace(
                    f"function animated_java:{rig_dir.name}/animations/{animation_dir.name}/zzz/apply_frame", 
                    f"execute on passengers if entity @s[type=marker] run function animated_java:{rig_dir.name}/animations/{animation_dir.name}/zzz/apply_frame"
                )
            elif (need_modified_function.parent.name, need_modified_function.name) == ("zzz","apply_frame.mcfunction"):
                modified_content = content.replace(
                    "execute on passengers if entity @s[type=marker] run ", 
                    ""
                )
            else:
                modified_content = content.replace(
                    f"execute at @s run function animated_java:test/animations/animation.model.new/zzz/apply_frame", 
                    f"execute at @s on passengers if entity @s[type=marker] run function animated_java:{rig_dir.name}/animations/{animation_dir.name}/zzz/apply_frame"
                )
            file.seek(0)
            file.truncate()
            file.write(modified_content)


if __name__ == "__main__":
    for rig_dir in RIG_DIRS:
        modify_rig_dir(rig_dir)