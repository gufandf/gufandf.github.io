for i in range(50):
    print(f'execute if score @s colddown matches {i}..{i} run title @s actionbar "{"|"*(i-1)}"')